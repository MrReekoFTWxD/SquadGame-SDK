#pragma once 
#include <AK74GP25_UGL_Skeleton_AnimBlueprint_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AK74GP25_UGL_Skeleton_AnimBlueprint.AK74GP25_UGL_Skeleton_AnimBlueprint_C
// Size: 0x678(Inherited: 0x300) 
struct UAK74GP25_UGL_Skeleton_AnimBlueprint_C : public USQWeaponAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x300(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x308(0x30)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x338(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x3F8(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x440(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x488(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x4D0(0x80)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x550(0xC0)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x610(0x18)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x628(0x50)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AK74GP25_UGL_Skeleton_AnimBlueprint.AK74GP25_UGL_Skeleton_AnimBlueprint_C.AnimGraph
	void ExecuteUbergraph_AK74GP25_UGL_Skeleton_AnimBlueprint(int32_t EntryPoint); // Function AK74GP25_UGL_Skeleton_AnimBlueprint.AK74GP25_UGL_Skeleton_AnimBlueprint_C.ExecuteUbergraph_AK74GP25_UGL_Skeleton_AnimBlueprint
}; 



