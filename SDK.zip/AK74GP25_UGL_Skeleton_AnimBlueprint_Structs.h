#pragma once 
#include "SDK.h" 
 
 
// Function AK74GP25_UGL_Skeleton_AnimBlueprint.AK74GP25_UGL_Skeleton_AnimBlueprint_C.ExecuteUbergraph_AK74GP25_UGL_Skeleton_AnimBlueprint
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AK74GP25_UGL_Skeleton_AnimBlueprint
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function AK74GP25_UGL_Skeleton_AnimBlueprint.AK74GP25_UGL_Skeleton_AnimBlueprint_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
