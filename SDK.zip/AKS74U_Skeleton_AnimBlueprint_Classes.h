#pragma once 
#include <AKS74U_Skeleton_AnimBlueprint_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AKS74U_Skeleton_AnimBlueprint.AKS74U_Skeleton_AnimBlueprint_C
// Size: 0x630(Inherited: 0x300) 
struct UAKS74U_Skeleton_AnimBlueprint_C : public USQWeaponAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x300(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x308(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x338(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x380(0x80)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x400(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x4C0(0x48)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x508(0x18)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x520(0xC0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x5E0(0x50)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AKS74U_Skeleton_AnimBlueprint.AKS74U_Skeleton_AnimBlueprint_C.AnimGraph
	void ExecuteUbergraph_AKS74U_Skeleton_AnimBlueprint(int32_t EntryPoint); // Function AKS74U_Skeleton_AnimBlueprint.AKS74U_Skeleton_AnimBlueprint_C.ExecuteUbergraph_AKS74U_Skeleton_AnimBlueprint
}; 



