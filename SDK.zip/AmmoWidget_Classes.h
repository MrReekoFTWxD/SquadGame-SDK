#pragma once 
#include <AmmoWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AmmoWidget.AmmoWidget_C
// Size: 0x3D0(Inherited: 0x370) 
struct UAmmoWidget_C : public USQAmmoWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x370(0x8)
	struct UTextBlock* BPAmmoCountTextBlock;  // 0x378(0x8)
	struct UImage* BPChamberedRound;  // 0x380(0x8)
	struct UTextBlock* BPFiremode;  // 0x388(0x8)
	struct UTextBlock* BPWeaponName;  // 0x390(0x8)
	struct UTextBlock* BPZeroingTextblock;  // 0x398(0x8)
	struct UCanvasPanel* CanvasPanel_2;  // 0x3A0(0x8)
	struct UCanvasPanel* CanvasWeaponName;  // 0x3A8(0x8)
	struct UMagazineGroupWidget_C* MagGroup1;  // 0x3B0(0x8)
	struct UMagazineGroupWidget_C* MagGroup2;  // 0x3B8(0x8)
	struct UUMG_VehicleCargo_C* UMG_VehicleCargo_610;  // 0x3C0(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_2;  // 0x3C8(0x8)

	void Construct(); // Function AmmoWidget.AmmoWidget_C.Construct
	void BPInit(); // Function AmmoWidget.AmmoWidget_C.BPInit
	void OnCurrentWeaponChanged(); // Function AmmoWidget.AmmoWidget_C.OnCurrentWeaponChanged
	void OnShowResourceAmounts(); // Function AmmoWidget.AmmoWidget_C.OnShowResourceAmounts
	void OnShowCurrentWeapon(); // Function AmmoWidget.AmmoWidget_C.OnShowCurrentWeapon
	void ExecuteUbergraph_AmmoWidget(int32_t EntryPoint); // Function AmmoWidget.AmmoWidget_C.ExecuteUbergraph_AmmoWidget
}; 



