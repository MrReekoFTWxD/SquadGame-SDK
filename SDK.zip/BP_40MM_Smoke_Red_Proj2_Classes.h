#pragma once 
#include <BP_40MM_Smoke_Red_Proj2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_40MM_Smoke_Red_Proj2.BP_40MM_Smoke_Red_Proj2_C
// Size: 0x540(Inherited: 0x540) 
struct ABP_40MM_Smoke_Red_Proj2_C : public ABP_40MM_Smoke_Proj2_C
{

}; 



