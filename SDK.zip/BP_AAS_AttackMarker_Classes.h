#pragma once 
#include <BP_AAS_AttackMarker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AAS_AttackMarker.BP_AAS_AttackMarker_C
// Size: 0x268(Inherited: 0x260) 
struct ABP_AAS_AttackMarker_C : public ASQMapMarker
{
	struct USceneComponent* DefaultSceneRoot;  // 0x260(0x8)

}; 



