#pragma once 
#include <BP_AAS_DefendMarker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AAS_DefendMarker.BP_AAS_DefendMarker_C
// Size: 0x268(Inherited: 0x260) 
struct ABP_AAS_DefendMarker_C : public ASQMapMarker
{
	struct USceneComponent* DefaultSceneRoot;  // 0x260(0x8)

}; 



