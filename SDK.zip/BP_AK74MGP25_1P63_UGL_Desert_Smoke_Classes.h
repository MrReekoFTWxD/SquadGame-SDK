#pragma once 
#include <BP_AK74MGP25_1P63_UGL_Desert_Smoke_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74MGP25_1P63_UGL_Desert_Smoke.BP_AK74MGP25_1P63_UGL_Desert_Smoke_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74MGP25_1P63_UGL_Desert_Smoke_C : public ABP_AK74MGP25_1P63_UGL_Desert_Parent_C
{

}; 



