#pragma once 
#include <BP_AK74M_4Mags_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74M_4Mags.BP_AK74M_4Mags_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74M_4Mags_C : public ABP_AK74M_C
{

}; 



