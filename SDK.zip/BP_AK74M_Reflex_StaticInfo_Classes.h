#pragma once 
#include <BP_AK74M_Reflex_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74M_Reflex_StaticInfo.BP_AK74M_Reflex_StaticInfo_C
// Size: 0x9B0(Inherited: 0x9B0) 
struct UBP_AK74M_Reflex_StaticInfo_C : public UBP_AK74M_StaticInfo_C
{

}; 



