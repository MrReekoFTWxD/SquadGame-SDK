#pragma once 
#include <BP_AK74_Recruit_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74_Recruit.BP_AK74_Recruit_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74_Recruit_C : public ABP_AK74_C
{

}; 



