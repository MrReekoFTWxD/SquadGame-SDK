#pragma once 
#include <BP_AKS74U_4mags_Founders_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74U_4mags_Founders.BP_AKS74U_4mags_Founders_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AKS74U_4mags_Founders_C : public ABP_AKS74U_4mags_C
{

}; 



