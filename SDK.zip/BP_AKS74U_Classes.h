#pragma once 
#include <BP_AKS74U_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74U.BP_AKS74U_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AKS74U_C : public ABP_AK74_C
{

}; 



