#pragma once 
#include <BP_AKS74U_Founder_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74U_Founder.BP_AKS74U_Founder_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AKS74U_Founder_C : public ABP_AKS74U_C
{

}; 



