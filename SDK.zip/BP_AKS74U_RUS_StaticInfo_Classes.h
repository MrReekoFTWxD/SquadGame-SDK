#pragma once 
#include <BP_AKS74U_RUS_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74U_RUS_StaticInfo.BP_AKS74U_RUS_StaticInfo_C
// Size: 0x9B0(Inherited: 0x9B0) 
struct UBP_AKS74U_RUS_StaticInfo_C : public UBP_AKS74U_StaticInfo_C
{

}; 



