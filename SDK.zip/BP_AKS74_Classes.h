#pragma once 
#include <BP_AKS74_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74.BP_AKS74_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AKS74_C : public ABP_AK74_C
{

}; 



