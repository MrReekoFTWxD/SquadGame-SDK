#pragma once 
#include <BP_ActionModel_Deployable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActionModel_Deployable.BP_ActionModel_Deployable_C
// Size: 0x168(Inherited: 0xA8) 
struct UBP_ActionModel_Deployable_C : public UBP_RadialActionModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FSQAvailabilityState_Deployable DeployableState;  // 0xB0(0x50)
	struct FSQDeployableEntry DeployableEntry;  // 0x100(0x68)

	void GetCost(bool& Out Has Cost, struct TArray<struct FSQCostEntry>& Out Cost); // Function BP_ActionModel_Deployable.BP_ActionModel_Deployable_C.GetCost
	void Open Voice Model(); // Function BP_ActionModel_Deployable.BP_ActionModel_Deployable_C.Open Voice Model
	void OnClicked(struct UBaseRadialMenu_C* Radial); // Function BP_ActionModel_Deployable.BP_ActionModel_Deployable_C.OnClicked
	void ExecuteUbergraph_BP_ActionModel_Deployable(int32_t EntryPoint); // Function BP_ActionModel_Deployable.BP_ActionModel_Deployable_C.ExecuteUbergraph_BP_ActionModel_Deployable
}; 



