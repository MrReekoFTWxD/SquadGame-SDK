#pragma once 
#include <BP_Action_Deployable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Action_Deployable.BP_Action_Deployable_C
// Size: 0x38(Inherited: 0x30) 
struct UBP_Action_Deployable_C : public UBP_RadialAction_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)

	void DoAction(struct UBaseRadialMenu_C* Radial, struct USQDeployableSettings* Deployable); // Function BP_Action_Deployable.BP_Action_Deployable_C.DoAction
	void ExecuteUbergraph_BP_Action_Deployable(int32_t EntryPoint); // Function BP_Action_Deployable.BP_Action_Deployable_C.ExecuteUbergraph_BP_Action_Deployable
}; 



