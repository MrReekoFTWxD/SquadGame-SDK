#pragma once 
#include <BP_AimBlurCameraEffect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C
// Size: 0x5D0(Inherited: 0x5A0) 
struct UBP_AimBlurCameraEffect_C : public USQLocalCameraEffectHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x5A0(0x8)
	struct ASQPlayerController* PlayerController;  // 0x5A8(0x8)
	struct UMaterialInstanceDynamic* Mid;  // 0x5B0(0x8)
	struct TArray<struct FWeightedBlendable> Blendables;  // 0x5B8(0x10)
	struct UMaterialInterface* ScopeBlurMaterial;  // 0x5C8(0x8)

	void BP_ApplyCameraEffect(float DeltaTime, struct ASQSoldier* SoldierToApplyTo); // Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.BP_ApplyCameraEffect
	void BP_InitCameraEffect(struct ASQPlayerController* InPlayerController); // Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.BP_InitCameraEffect
	void ExecuteUbergraph_BP_AimBlurCameraEffect(int32_t EntryPoint); // Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.ExecuteUbergraph_BP_AimBlurCameraEffect
}; 



