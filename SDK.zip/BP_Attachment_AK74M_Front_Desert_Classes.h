#pragma once 
#include <BP_Attachment_AK74M_Front_Desert_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_AK74M_Front_Desert.BP_Attachment_AK74M_Front_Desert_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_AK74M_Front_Desert_C : public UBP_Attachment_AK74M_Front_C
{

}; 



