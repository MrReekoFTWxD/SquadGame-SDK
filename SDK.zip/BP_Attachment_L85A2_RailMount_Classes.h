#pragma once 
#include <BP_Attachment_L85A2_RailMount_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_L85A2_RailMount.BP_Attachment_L85A2_RailMount_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_Attachment_L85A2_RailMount_C : public USQWeaponAttachment
{

}; 



