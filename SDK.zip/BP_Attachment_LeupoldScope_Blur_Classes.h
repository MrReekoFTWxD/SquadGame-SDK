#pragma once 
#include <BP_Attachment_LeupoldScope_Blur_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_LeupoldScope_Blur.BP_Attachment_LeupoldScope_Blur_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_LeupoldScope_Blur_C : public USQWeaponAttachment_Scope
{

}; 



