#pragma once 
#include <BP_Attachment_M150_Noads_Founders_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_M150_Noads_Founders.BP_Attachment_M150_Noads_Founders_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_M150_Noads_Founders_C : public USQWeaponAttachment_Scope
{

}; 



