#pragma once 
#include <BP_Attachment_M68_NoAds_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_M68_NoAds.BP_Attachment_M68_NoAds_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_M68_NoAds_C : public UBP_Attachment_M68_C
{

}; 



