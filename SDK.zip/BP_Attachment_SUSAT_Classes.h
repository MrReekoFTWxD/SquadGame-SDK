#pragma once 
#include <BP_Attachment_SUSAT_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_SUSAT.BP_Attachment_SUSAT_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_SUSAT_C : public USQWeaponAttachment_Scope
{

}; 



