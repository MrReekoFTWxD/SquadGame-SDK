#pragma once 
#include <BP_Attachment_SVD_front_wood_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_SVD_front_wood.BP_Attachment_SVD_front_wood_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_SVD_front_wood_C : public USQWeaponAttachment_Scope
{

}; 



