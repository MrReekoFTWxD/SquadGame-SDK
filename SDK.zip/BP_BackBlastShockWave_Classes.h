#pragma once 
#include <BP_BackBlastShockWave_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BackBlastShockWave.BP_BackBlastShockWave_C
// Size: 0x258(Inherited: 0x250) 
struct ABP_BackBlastShockWave_C : public ABP_Shockwave_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x250(0x8)

	void BackBlastShockWave(struct AActor* Instigator); // Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.BackBlastShockWave
	void Explode(struct AActor* Instigator); // Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.Explode
	void ExecuteUbergraph_BP_BackBlastShockWave(int32_t EntryPoint); // Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.ExecuteUbergraph_BP_BackBlastShockWave
}; 



