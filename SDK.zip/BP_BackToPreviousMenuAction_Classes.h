#pragma once 
#include <BP_BackToPreviousMenuAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C
// Size: 0x38(Inherited: 0x30) 
struct UBP_BackToPreviousMenuAction_C : public UBP_RadialAction_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)

	void CanClick(struct APlayerController* Controller, struct UBP_RadialItemModel_C* Model, bool& CanClick); // Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.CanClick
	void OnClicked(struct UBaseRadialMenu_C* Raidal Menu); // Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.OnClicked
	void ExecuteUbergraph_BP_BackToPreviousMenuAction(int32_t EntryPoint); // Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.ExecuteUbergraph_BP_BackToPreviousMenuAction
}; 



