#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseRoleChangeModel.BP_BaseRoleChangeModel_C.ExecuteUbergraph_BP_BaseRoleChangeModel
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseRoleChangeModel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_Radial;  // 0x8(0x8)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0x10(0x8)
	struct UBP_ChangeRoleActionx_C* K2Node_DynamicCast_AsBP_Change_Role_Actionx;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_BaseRoleChangeModel.BP_BaseRoleChangeModel_C.OnClicked
// Size: 0x8(Inherited: 0x8) 
struct FOnClicked : public FOnClicked
{
	struct UBaseRadialMenu_C* Radial;  // 0x0(0x8)

}; 
