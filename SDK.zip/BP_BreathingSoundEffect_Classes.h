#pragma once 
#include <BP_BreathingSoundEffect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BreathingSoundEffect.BP_BreathingSoundEffect_C
// Size: 0x60(Inherited: 0x30) 
struct UBP_BreathingSoundEffect_C : public USQLocalAudioPlayer
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)
	struct USoundBase* calm;  // 0x38(0x8)
	struct USoundBase* Medium;  // 0x40(0x8)
	struct USoundBase* Heavy;  // 0x48(0x8)
	struct USoundBase* Drowning;  // 0x50(0x8)
	float ADSFocusBreathingMinimumTimeStationary;  // 0x58(0x4)
	float TimeStationary;  // 0x5C(0x4)

	void BP_InitAudioEffect(struct UAudioComponent* AudioComponent); // Function BP_BreathingSoundEffect.BP_BreathingSoundEffect_C.BP_InitAudioEffect
	void BP_UpdateAudioComponent(float DeltaTime, struct UAudioComponent* AudioComponent, struct ASQSoldier* SoldierToApplyTo); // Function BP_BreathingSoundEffect.BP_BreathingSoundEffect_C.BP_UpdateAudioComponent
	void ExecuteUbergraph_BP_BreathingSoundEffect(int32_t EntryPoint); // Function BP_BreathingSoundEffect.BP_BreathingSoundEffect_C.ExecuteUbergraph_BP_BreathingSoundEffect
}; 



