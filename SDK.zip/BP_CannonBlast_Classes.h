#pragma once 
#include <BP_CannonBlast_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CannonBlast.BP_CannonBlast_C
// Size: 0xD8(Inherited: 0xD8) 
struct UBP_CannonBlast_C : public USQShockwaveDirected
{

}; 



