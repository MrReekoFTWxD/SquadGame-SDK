#pragma once 
#include <BP_CaptureZoneMain_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CaptureZoneMain.BP_CaptureZoneMain_C
// Size: 0x250(Inherited: 0x228) 
struct ABP_CaptureZoneMain_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x228(0x8)
	struct USphereComponent* Sphere;  // 0x230(0x8)
	struct USQCaptureZoneResourceComponent* SQCaptureZoneResource;  // 0x238(0x8)
	struct USQCaptureZoneComponent* SQCaptureZone;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)

	int32_t GetTeamId(); // Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.GetTeamId
	void OnTeamChange(int32_t PreviousTeam); // Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.OnTeamChange
	void ReceiveBeginPlay(); // Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_CaptureZoneMain(int32_t EntryPoint); // Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.ExecuteUbergraph_BP_CaptureZoneMain
}; 



