#pragma once 
#include "SDK.h" 
 
 
// Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.OnTeamChange
// Size: 0x4(Inherited: 0x0) 
struct FOnTeamChange
{
	int32_t PreviousTeam;  // 0x0(0x4)

}; 
// Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.ExecuteUbergraph_BP_CaptureZoneMain
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CaptureZoneMain
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t K2Node_Event_PreviousTeam;  // 0x4(0x4)

}; 
// Function BP_CaptureZoneMain.BP_CaptureZoneMain_C.GetTeamId
// Size: 0x8(Inherited: 0x0) 
struct FGetTeamId
{
	int32_t ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x4(0x4)

}; 
