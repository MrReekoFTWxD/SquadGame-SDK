#pragma once 
#include <BP_CommandActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CommandActor.BP_CommandActor_C
// Size: 0x268(Inherited: 0x248) 
struct ABP_CommandActor_C : public ASQCommandActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x248(0x8)
	struct UArrowComponent* Arrow;  // 0x250(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool Action Destroyed : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float Destroy Delay after Action Destroyed;  // 0x264(0x4)

	void Server Start Active Duration(); // Function BP_CommandActor.BP_CommandActor_C.Server Start Active Duration
	void Server End Active Duration(); // Function BP_CommandActor.BP_CommandActor_C.Server End Active Duration
	void Try to Load and Play Sound(char ID); // Function BP_CommandActor.BP_CommandActor_C.Try to Load and Play Sound
	void Owner Load and Play Sound(char ID); // Function BP_CommandActor.BP_CommandActor_C.Owner Load and Play Sound
	void Server Destroy Action(); // Function BP_CommandActor.BP_CommandActor_C.Server Destroy Action
	void Multi Death Cosmetics(); // Function BP_CommandActor.BP_CommandActor_C.Multi Death Cosmetics
	void ReceiveBeginPlay(); // Function BP_CommandActor.BP_CommandActor_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_CommandActor(int32_t EntryPoint); // Function BP_CommandActor.BP_CommandActor_C.ExecuteUbergraph_BP_CommandActor
}; 



