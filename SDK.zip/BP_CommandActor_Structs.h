#pragma once 
#include "SDK.h" 
 
 
// Function BP_CommandActor.BP_CommandActor_C.ExecuteUbergraph_BP_CommandActor
// Size: 0x158(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CommandActor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_GetTeam_ReturnValue;  // 0x1C(0x4)
	char Temp_byte_Variable;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x21(0x1)
	char Temp_byte_Variable_2;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x23(0x1)
	char pad_36[12];  // 0x24(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x30(0x30)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x6C(0x4)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x7C(0x10)
	char pad_140[4];  // 0x8C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x98(0x10)
	char K2Node_CustomEvent_ID_2;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0xB0(0x8)
	struct TSoftObjectPtr<USoundCue> K2Node_Select_Default;  // 0xB8(0x28)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0xE0(0x1)
	char K2Node_CustomEvent_ID;  // 0xE1(0x1)
	char pad_226[6];  // 0xE2(0x6)
	struct TSoftObjectPtr<USoundCue> K2Node_Select_Default_2;  // 0xE8(0x28)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x110(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller_2;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x128(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller_3;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct UUI_Events_Component_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x150(0x8)

}; 
// Function BP_CommandActor.BP_CommandActor_C.Owner Load and Play Sound
// Size: 0x1(Inherited: 0x0) 
struct FOwner Load and Play Sound
{
	char ID;  // 0x0(0x1)

}; 
// Function BP_CommandActor.BP_CommandActor_C.Try to Load and Play Sound
// Size: 0x1(Inherited: 0x0) 
struct FTry to Load and Play Sound
{
	char ID;  // 0x0(0x1)

}; 
