#pragma once 
#include <BP_CommanderActionCondition_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CommanderActionCondition.BP_CommanderActionCondition_C
// Size: 0x30(Inherited: 0x28) 
struct UBP_CommanderActionCondition_C : public UObject
{
	struct ASQGameState* GameState;  // 0x28(0x8)

	void Can Use Actions(struct ASQPlayerController* Player, USQGridData_CommandOption* Command Option, bool Require Active, bool& Valid, struct FText& Out Reason); // Function BP_CommanderActionCondition.BP_CommanderActionCondition_C.Can Use Actions
}; 



