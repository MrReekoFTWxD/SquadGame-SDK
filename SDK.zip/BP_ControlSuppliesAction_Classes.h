#pragma once 
#include <BP_ControlSuppliesAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ControlSuppliesAction.BP_ControlSuppliesAction_C
// Size: 0x30(Inherited: 0x30) 
struct UBP_ControlSuppliesAction_C : public UBP_RadialAction_C
{

}; 



