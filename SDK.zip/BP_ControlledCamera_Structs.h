#pragma once 
#include "SDK.h" 
 
 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Created Button__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FCreated Button__DelegateSignature
{
	struct UW_CamControlButton_C* Cam Button;  // 0x0(0x8)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.ExecuteUbergraph_BP_ControlledCamera
// Size: 0x218(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ControlledCamera
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FAnchors K2Node_MakeStruct_Anchors;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FKey K2Node_InputActionEvent_Key;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x3C(0x4)
	float K2Node_InputAxisEvent_AxisValue;  // 0x40(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x44(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Temp_bool_Variable : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FKey Temp_struct_Variable;  // 0x60(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x78(0x18)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_CustomEvent_Active : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct APlayerController* K2Node_Event_PC_2;  // 0x98(0x8)
	struct APlayerController* K2Node_Event_PC;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Can_Become_View_Target_Can_View : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0xB0(0x18)
	struct UW_CameraWidget_C* CallFunc_Create_ReturnValue;  // 0xC8(0x8)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0xD0(0x18)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xF9(0x1)
	char pad_250[6];  // 0xFA(0x6)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x110(0x8)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct TScriptInterface<IBPI_HUD_C> K2Node_DynamicCast_AsBPI_HUD;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_IsInVehicle_ReturnValue : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct AActor* K2Node_Select_Default;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsAdminCamera_ReturnValue : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x149(0x1)
	char pad_330[6];  // 0x14A(0x6)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x150(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue_3;  // 0x158(0x8)
	struct TScriptInterface<IBPI_HUD_C> K2Node_DynamicCast_AsBPI_HUD_2;  // 0x160(0x10)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct ASQHUD* K2Node_DynamicCast_AsSQHUD;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct ASQHUD* K2Node_DynamicCast_AsSQHUD_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x198(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x1A0(0x8)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x1B0(0x1)
	char pad_433[7];  // 0x1B1(0x7)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier_2;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct ASQPlayerCameraManager* K2Node_DynamicCast_AsSQPlayer_Camera_Manager;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x1D0(0x1)
	char pad_465[7];  // 0x1D1(0x7)
	struct ASQPlayerCameraManager* K2Node_DynamicCast_AsSQPlayer_Camera_Manager_2;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	float CallFunc_GetLastNearClipPlane_ReturnValue;  // 0x1E4(0x4)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x1E8(0x18)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x200(0x1)
	char pad_513[3];  // 0x201(0x3)
	float Temp_float_Variable;  // 0x204(0x4)
	float Temp_float_Variable_2;  // 0x208(0x4)
	float K2Node_Select_Default_2;  // 0x20C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x210(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x214(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Toggle View
// Size: 0x1(Inherited: 0x0) 
struct FToggle View
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Active : 1;  // 0x0(0x1)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.K2_OnEndViewTarget
// Size: 0x8(Inherited: 0x8) 
struct FK2_OnEndViewTarget : public FK2_OnEndViewTarget
{
	struct APlayerController* PC;  // 0x0(0x8)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.K2_OnBecomeViewTarget
// Size: 0x8(Inherited: 0x8) 
struct FK2_OnBecomeViewTarget : public FK2_OnBecomeViewTarget
{
	struct APlayerController* PC;  // 0x0(0x8)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Interact_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interact_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_ToggleStabilization_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ToggleStabilization_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Sprint_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Sprint_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Can Become View Target
// Size: 0x1(Inherited: 0x0) 
struct FCan Become View Target
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Can View : 1;  // 0x0(0x1)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Sprint_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Sprint_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_LeanLeft_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeanLeft_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Add Zoom Delta
// Size: 0x1C(Inherited: 0x0) 
struct FAdd Zoom Delta
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t K2Node_Select_Default;  // 0x18(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Add Camera Movement
// Size: 0x174(Inherited: 0x0) 
struct FAdd Camera Movement
{
	float X Delta;  // 0x0(0x4)
	float Y Delta;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_2 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	float CallFunc_BreakRotator_Roll;  // 0xC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x14(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0x18(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x20(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x24(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x30(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x34(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x3C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x40(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x44(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x48(0xC)
	float CallFunc_FClamp_ReturnValue_2;  // 0x54(0x4)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x58(0x88)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0xE0(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0xEC(0x88)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Clamp Camera Rotation
// Size: 0xC(Inherited: 0x0) 
struct FClamp Camera Rotation
{
	struct FVector L Look at Vector;  // 0x0(0xC)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Update Zoom
// Size: 0x8(Inherited: 0x0) 
struct FUpdate Zoom
{
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x0(0x4)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0x4(0x4)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Init Camera
// Size: 0xC1(Inherited: 0x0) 
struct FInit Camera
{
	struct AActor* CallFunc_GetAttachParentActor_ReturnValue;  // 0x0(0x8)
	struct AActor* CallFunc_GetAttachParentActor_ReturnValue_2;  // 0x8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x3C(0x10)
	char pad_76[4];  // 0x4C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x60(0x8)
	struct TScriptInterface<IBPI_HUD_C> K2Node_DynamicCast_AsBPI_HUD;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UW_CamControlButton_C* CallFunc_Create_ReturnValue;  // 0x80(0x8)
	struct UUMG_MenuBase_C* CallFunc_Get_Main_Menus_Deployment;  // 0x88(0x8)
	struct UUMG_MenuBase_C* CallFunc_Get_Main_Menus_Command;  // 0x90(0x8)
	struct UUMG_MenuBase_C* CallFunc_Get_Main_Menus_Roaming;  // 0x98(0x8)
	struct UW_CommandUI_C* K2Node_DynamicCast_AsW_Command_UI;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0xB0(0x8)
	struct USQGridData_CommandOption* K2Node_DynamicCast_AsSQGrid_Data_Command_Option;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xC0(0x1)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Find Vehicle
// Size: 0x1B9(Inherited: 0x0) 
struct FFind Vehicle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Found Vehicle : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x2C(0xC)
	struct ATargetPoint* K2Node_DynamicCast_AsTarget_Point;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct AActor* CallFunc_GetAttachParentActor_ReturnValue;  // 0x60(0x8)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x68(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x78(0x10)
	struct TArray<struct FHitResult> CallFunc_BoxTraceMultiForObjects_OutHits;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_BoxTraceMultiForObjects_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	struct FHitResult CallFunc_Array_Get_Item;  // 0xA4(0x88)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x12C(0x1)
	char pad_301_1 : 7;  // 0x12D(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x12D(0x1)
	char pad_302[2];  // 0x12E(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x130(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x134(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x138(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x150(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x15C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x168(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x170(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x178(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x180(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x188(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x18C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x190(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x194(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1A0(0xC)
	char pad_428[4];  // 0x1AC(0x4)
	struct ASQVehicle* K2Node_DynamicCast_AsSQVehicle;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1B8(0x1)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Update Follow
// Size: 0x26C(Inherited: 0x0) 
struct FUpdate Follow
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct ASQVehicle* K2Node_DynamicCast_AsSQVehicle;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x20(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x2C(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x38(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x3C(0xC)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x50(0x30)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x80(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x8C(0x4)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue;  // 0x90(0xC)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // 0x9C(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0xA8(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0xAC(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0xB0(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0xB4(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0xB8(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0xBC(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC0(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0xC4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xC8(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xD4(0x88)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x15C(0xC)
	char pad_360[8];  // 0x168(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x170(0x30)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x1A0(0xC)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue_2;  // 0x1AC(0xC)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue_2;  // 0x1B8(0xC)
	float CallFunc_BreakRotator_Roll_4;  // 0x1C4(0x4)
	float CallFunc_BreakRotator_Pitch_4;  // 0x1C8(0x4)
	float CallFunc_BreakRotator_Yaw_4;  // 0x1CC(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x1D0(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x1D4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x1D8(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x1E4(0x88)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Create Stabilisation Point
// Size: 0x230(Inherited: 0x0) 
struct FCreate Stabilisation Point
{
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ATargetPoint* K2Node_DynamicCast_AsTarget_Point;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_Find_Vehicle_Found_Vehicle : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x48(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x54(0x88)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xDC(0x1)
	char pad_221_1 : 7;  // 0xDD(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xDD(0x1)
	char pad_222_1 : 7;  // 0xDE(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xDE(0x1)
	char pad_223[1];  // 0xDF(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xE0(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xF4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x100(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x10C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x118(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x120(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x128(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x130(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x138(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x13C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x140(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x150(0xC)
	char pad_348[4];  // 0x15C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x160(0x30)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x190(0x88)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x218(0x1)
	char pad_537[7];  // 0x219(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x220(0x8)
	struct ATargetPoint* CallFunc_FinishSpawningActor_ReturnValue;  // 0x228(0x8)

}; 
// Function BP_ControlledCamera.BP_ControlledCamera_C.Check Soldier Wound
// Size: 0x1F(Inherited: 0x0) 
struct FCheck Soldier Wound
{
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1E(0x1)

}; 
