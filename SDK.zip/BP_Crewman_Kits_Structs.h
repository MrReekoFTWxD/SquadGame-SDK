#pragma once 
#include "SDK.h" 
 
 
// Function BP_Crewman_Kits.BP_Crewman_Kits_C.ExecuteUbergraph_BP_Crewman_Kits
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Crewman_Kits
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_BaseRadialMenu;  // 0x8(0x8)

}; 
// Function BP_Crewman_Kits.BP_Crewman_Kits_C.ShouldUseRole
// Size: 0xA(Inherited: 0x9) 
struct FShouldUseRole : public FShouldUseRole
{
	struct UBP_SQRoleSettings_C* In Role;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Out ShouldUse : 1;  // 0x8(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_Crewman_Kits.BP_Crewman_Kits_C.CreateChildWidgets
// Size: 0x8(Inherited: 0x8) 
struct FCreateChildWidgets : public FCreateChildWidgets
{
	struct UBaseRadialMenu_C* BaseRadialMenu;  // 0x0(0x8)

}; 
