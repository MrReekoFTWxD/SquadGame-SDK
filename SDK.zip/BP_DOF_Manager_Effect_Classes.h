#pragma once 
#include <BP_DOF_Manager_Effect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C
// Size: 0x5C4(Inherited: 0x5A0) 
struct UBP_DOF_Manager_Effect_C : public USQLocalCameraEffectHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x5A0(0x8)
	float Apeture Target;  // 0x5A8(0x4)
	float DistanceTarget;  // 0x5AC(0x4)
	float Apeture Blend Time;  // 0x5B0(0x4)
	float Dist Blend Time;  // 0x5B4(0x4)
	struct ABP_PlayerController_C* PlayerController;  // 0x5B8(0x8)
	float CachedFOVSetting;  // 0x5C0(0x4)

	void BP_ApplyCameraEffect(float DeltaTime, struct ASQSoldier* SoldierToApplyTo); // Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.BP_ApplyCameraEffect
	void BP_InitCameraEffect(struct ASQPlayerController* InPlayerController); // Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.BP_InitCameraEffect
	void RefreshCachedFOVSetting(struct USQGameUserSettings* UserSettings); // Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.RefreshCachedFOVSetting
	void ExecuteUbergraph_BP_DOF_Manager_Effect(int32_t EntryPoint); // Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.ExecuteUbergraph_BP_DOF_Manager_Effect
}; 



