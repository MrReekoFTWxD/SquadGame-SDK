#pragma once 
#include <BP_DynamicSpecificKits_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DynamicSpecificKits.BP_DynamicSpecificKits_C
// Size: 0x78(Inherited: 0x70) 
struct UBP_DynamicSpecificKits_C : public UBP_SpecificKits_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x70(0x8)

	void ShouldUseRole(struct UBP_SQRoleSettings_C* In Role, bool& Out ShouldUse); // Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.ShouldUseRole
	void Create Widgets(struct UBaseRadialMenu_C* Base Radial); // Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.Create Widgets
	void ExecuteUbergraph_BP_DynamicSpecificKits(int32_t EntryPoint); // Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.ExecuteUbergraph_BP_DynamicSpecificKits
}; 



