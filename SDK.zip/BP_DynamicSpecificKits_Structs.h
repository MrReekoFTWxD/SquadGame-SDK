#pragma once 
#include "SDK.h" 
 
 
// Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.ExecuteUbergraph_BP_DynamicSpecificKits
// Size: 0xC4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DynamicSpecificKits
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_Base_Radial;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<ISQRearmSource> K2Node_DynamicCast_AsSQRearm_Source;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct TArray<struct FSQAvailabilityState_Role> CallFunc_GetRolesForRearm_OutRoles;  // 0x40(0x10)
	struct FSQAvailabilityState_Role CallFunc_Array_Get_Item;  // 0x50(0x58)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xAC(0x4)
	struct UBP_SQRoleSettings_C* K2Node_DynamicCast_AsBP_SQRole_Settings;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_ShouldUseRole_Out_ShouldUse : 1;  // 0xBA(0x1)
	char pad_187[1];  // 0xBB(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xC0(0x4)

}; 
// Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.Create Widgets
// Size: 0x8(Inherited: 0xB1) 
struct FCreate Widgets : public FCreate Widgets
{
	struct UBaseRadialMenu_C* Base Radial;  // 0x0(0x8)

}; 
// Function BP_DynamicSpecificKits.BP_DynamicSpecificKits_C.ShouldUseRole
// Size: 0x9(Inherited: 0x0) 
struct FShouldUseRole
{
	struct UBP_SQRoleSettings_C* In Role;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Out ShouldUse : 1;  // 0x8(0x1)

}; 
