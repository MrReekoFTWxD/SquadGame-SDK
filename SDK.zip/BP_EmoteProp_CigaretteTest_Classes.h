#pragma once 
#include <BP_EmoteProp_CigaretteTest_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmoteProp_CigaretteTest.BP_EmoteProp_CigaretteTest_C
// Size: 0x268(Inherited: 0x248) 
struct ABP_EmoteProp_CigaretteTest_C : public ASQEmoteProp
{
	struct UStaticMeshComponent* Cylinder;  // 0x248(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x250(0x8)
	struct UParticleSystemComponent* Smoke1;  // 0x258(0x8)
	struct UParticleSystemComponent* Smoke;  // 0x260(0x8)

}; 



