#pragma once 
#include <BP_EmotesMenuRadialCenterText_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmotesMenuRadialCenterText.BP_EmotesMenuRadialCenterText_C
// Size: 0xB0(Inherited: 0xA8) 
struct UBP_EmotesMenuRadialCenterText_C : public UBP_RadialActionModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void OnClicked(struct UBaseRadialMenu_C* Radial); // Function BP_EmotesMenuRadialCenterText.BP_EmotesMenuRadialCenterText_C.OnClicked
	void ExecuteUbergraph_BP_EmotesMenuRadialCenterText(int32_t EntryPoint); // Function BP_EmotesMenuRadialCenterText.BP_EmotesMenuRadialCenterText_C.ExecuteUbergraph_BP_EmotesMenuRadialCenterText
}; 



