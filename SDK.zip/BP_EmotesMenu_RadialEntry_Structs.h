#pragma once 
#include "SDK.h" 
 
 
// Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.ExecuteUbergraph_BP_EmotesMenu_RadialEntry
// Size: 0x78(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EmotesMenu_RadialEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_Radial;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct TSoftObjectPtr<USQEmotesData> CallFunc_Conv_ObjectToSoftObjectReference_ReturnValue;  // 0x48(0x28)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_2;  // 0x70(0x8)

}; 
// Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.OnClicked
// Size: 0x8(Inherited: 0x8) 
struct FOnClicked : public FOnClicked
{
	struct UBaseRadialMenu_C* Radial;  // 0x0(0x8)

}; 
// Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.CanClick
// Size: 0x68(Inherited: 0x0) 
struct FCanClick
{
	struct ASQPlayerController* PC;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bCanClick : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FString> ReturnValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ASQSoldier* CallFunc_GetSoldier_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct USQEmotePlayer* CallFunc_GetComponentByClass_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_CanPlayEmote_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct FString> CallFunc_GetRestrictionText_ReturnValue;  // 0x58(0x10)

}; 
