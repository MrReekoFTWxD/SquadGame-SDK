#pragma once 
#include <BP_EmplacedUB32_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmplacedUB32.BP_EmplacedUB32_C
// Size: 0xC38(Inherited: 0xC28) 
struct ABP_EmplacedUB32_C : public ABP_GenericDeployableWeapon_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xC28(0x8)
	struct USQBlastComponent* SQBlast;  // 0xC30(0x8)

	void BlueprintOnFire(struct FVector& Origin); // Function BP_EmplacedUB32.BP_EmplacedUB32_C.BlueprintOnFire
	void ExecuteUbergraph_BP_EmplacedUB32(int32_t EntryPoint); // Function BP_EmplacedUB32.BP_EmplacedUB32_C.ExecuteUbergraph_BP_EmplacedUB32
}; 



