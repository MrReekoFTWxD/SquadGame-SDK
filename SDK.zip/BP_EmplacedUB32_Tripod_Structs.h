#pragma once 
#include "SDK.h" 
 
 
// Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ExecuteUbergraph_BP_EmplacedUB32_Tripod
// Size: 0x81(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EmplacedUB32_Tripod
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x8(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x20(0x18)
	struct FKey Temp_struct_Variable;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct AController* K2Node_Event_NewController;  // 0x58(0x8)
	struct AController* K2Node_Event_OldController;  // 0x60(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller_2;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)

}; 
// Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.InpActEvt_Focus_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x18) 
struct FInpActEvt_Focus_K2Node_InputActionEvent_2 : public FInpActEvt_Focus_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ReceiveUnpossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessed : public FReceiveUnpossessed
{
	struct AController* OldController;  // 0x0(0x8)

}; 
// Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.InpActEvt_Focus_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Focus_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
