#pragma once 
#include <BP_EnemyScalingSpawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C
// Size: 0x41C(Inherited: 0x400) 
struct ABP_EnemyScalingSpawn_C : public ASQGameSpawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x400(0x8)
	struct USphereComponent* EnemyDetectionRadius;  // 0x408(0x8)
	int32_t EnemiesInRadius;  // 0x410(0x4)
	float RespawnDelayPerPerson;  // 0x414(0x4)
	int32_t NumEnemiesToDisable;  // 0x418(0x4)

	bool IsSameTeam(struct UObject* Object); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.IsSameTeam
	void OnEnemiesInRadiusChanged(); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.OnEnemiesInRadiusChanged
	float GetRespawnDelay(); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.GetRespawnDelay
	void BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_327_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_327_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_351_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_351_ComponentEndOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_EnemyScalingSpawn(int32_t EntryPoint); // Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.ExecuteUbergraph_BP_EnemyScalingSpawn
}; 



