#pragma once 
#include <BP_FlyingDrone_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlyingDrone.BP_FlyingDrone_C
// Size: 0x5B8(Inherited: 0x4C0) 
struct ABP_FlyingDrone_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UStaticMeshComponent* HitBox;  // 0x4C8(0x8)
	struct UAudioComponent* SC_QuadcoptersAudio;  // 0x4D0(0x8)
	struct UCameraComponent* Camera;  // 0x4D8(0x8)
	struct USQMapIconComponent* SQMapIcon;  // 0x4E0(0x8)
	struct USQCoreStateComponent* SQCoreState;  // 0x4E8(0x8)
	struct UStaticMeshComponent* Blade4;  // 0x4F0(0x8)
	struct UStaticMeshComponent* Blade3;  // 0x4F8(0x8)
	struct UStaticMeshComponent* Blade2;  // 0x500(0x8)
	struct UStaticMeshComponent* Blade;  // 0x508(0x8)
	struct UHealthComponent_C* HealthComponent;  // 0x510(0x8)
	struct UStaticMeshComponent* Body;  // 0x518(0x8)
	struct ASQPlayerController* SQ PC;  // 0x520(0x8)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool Dead : 1;  // 0x528(0x1)
	char pad_1321[7];  // 0x529(0x7)
	struct UParticleSystem* Explode Effect;  // 0x530(0x8)
	struct USoundBase* Explode Sound;  // 0x538(0x8)
	char pad_1344_1 : 7;  // 0x540(0x1)
	bool Can Possess : 1;  // 0x540(0x1)
	char pad_1345[7];  // 0x541(0x7)
	USQGridData_CommandOption* Command Action;  // 0x548(0x8)
	float CrashVelocity;  // 0x550(0x4)
	float Max Fly Height;  // 0x554(0x4)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool Can Increase Altitude : 1;  // 0x558(0x1)
	char pad_1369[7];  // 0x559(0x7)
	struct FTimerHandle Altitude Timer;  // 0x560(0x8)
	int32_t Zoom Level;  // 0x568(0x4)
	float Desired Zoom;  // 0x56C(0x4)
	struct TArray<float> Zoom Levels;  // 0x570(0x10)
	ABP_Smartphone_FPV_C* FPV Item Class;  // 0x580(0x8)
	float BankAngleLimit;  // 0x588(0x4)
	char pad_1420[4];  // 0x58C(0x4)
	struct FDebugFloatHistory DebugFloatHistory;  // 0x590(0x20)
	struct ABP_Smartphone_FPV_C* FPV Item;  // 0x5B0(0x8)

	void Check Owner Death(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Check Owner Death
	void Update Zoom(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Update Zoom
	void Add Zoom Delta(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Add Zoom Delta
	void Set Can Increase Altitude(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Set Can Increase Altitude
	void Update Relative Rotation(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Update Relative Rotation
	void InpActEvt_Interact_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpActEvt_Interact_K2Node_InputActionEvent_2
	void InpActEvt_LeanLeft_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpActEvt_LeanLeft_K2Node_InputActionEvent_1
	void InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_2
	void InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_3(float AxisValue); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_3
	void InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_4(float AxisValue); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_4
	void InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_5(float AxisValue); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_5
	void ReceiveTick(float DeltaSeconds); // Function BP_FlyingDrone.BP_FlyingDrone_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_FlyingDrone.BP_FlyingDrone_C.ReceiveBeginPlay
	void BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_Health Zero__DelegateSignature(); // Function BP_FlyingDrone.BP_FlyingDrone_C.BndEvt__HealthComponent_K2Node_ComponentBoundEvent_0_Health Zero__DelegateSignature
	void Multicast Destroy(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Multicast Destroy
	void Server Die(); // Function BP_FlyingDrone.BP_FlyingDrone_C.Server Die
	void End Flight(); // Function BP_FlyingDrone.BP_FlyingDrone_C.End Flight
	void Server Unpossess(bool Remove); // Function BP_FlyingDrone.BP_FlyingDrone_C.Server Unpossess
	void ReceivePossessed(struct AController* NewController); // Function BP_FlyingDrone.BP_FlyingDrone_C.ReceivePossessed
	void On Possess(struct FRotator& NewRotation); // Function BP_FlyingDrone.BP_FlyingDrone_C.On Possess
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_FlyingDrone.BP_FlyingDrone_C.ReceiveUnpossessed
	void On Depossess(); // Function BP_FlyingDrone.BP_FlyingDrone_C.On Depossess
	void Kit Changed(struct USQRoleSettings* CurrentRole); // Function BP_FlyingDrone.BP_FlyingDrone_C.Kit Changed
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_FlyingDrone.BP_FlyingDrone_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void InpAxisEvt_DroneElevation_K2Node_InputAxisEvent_6(float AxisValue); // Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_DroneElevation_K2Node_InputAxisEvent_6
	void ExecuteUbergraph_BP_FlyingDrone(int32_t EntryPoint); // Function BP_FlyingDrone.BP_FlyingDrone_C.ExecuteUbergraph_BP_FlyingDrone
}; 



