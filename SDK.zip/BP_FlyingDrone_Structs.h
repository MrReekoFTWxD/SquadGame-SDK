#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Kit Changed
// Size: 0x8(Inherited: 0x0) 
struct FKit Changed
{
	struct USQRoleSettings* CurrentRole;  // 0x0(0x8)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_DroneElevation_K2Node_InputAxisEvent_6
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_DroneElevation_K2Node_InputAxisEvent_6
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.ExecuteUbergraph_BP_FlyingDrone
// Size: 0x471(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlyingDrone
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct FKey K2Node_InputActionEvent_Key;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x34(0x10)
	float K2Node_InputAxisEvent_AxisValue_5;  // 0x44(0x4)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x50(0x4)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x60(0xC)
	char pad_108[4];  // 0x6C(0x4)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x70(0x18)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x88(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x8C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x90(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x94(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x98(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x9C(0x4)
	float K2Node_Event_DeltaSeconds;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0xA8(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0xC0(0x8)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_3;  // 0xC8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0xCC(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0xD0(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xDC(0xC)
	float CallFunc_VSize_ReturnValue;  // 0xE8(0x4)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0xEC(0x88)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x174(0x4)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x17C(0x10)
	char pad_396_1 : 7;  // 0x18C(0x1)
	bool K2Node_CustomEvent_Remove : 1;  // 0x18C(0x1)
	char pad_397[3];  // 0x18D(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x198(0x8)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1A8(0x1)
	char pad_425[7];  // 0x1A9(0x7)
	struct ASQSoldier* CallFunc_GetSoldier_ReturnValue;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1B9(0x1)
	char pad_442[2];  // 0x1BA(0x2)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x1BC(0xC)
	struct AController* K2Node_Event_NewController;  // 0x1C8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x1D0(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x1E0(0x8)
	struct FRotator K2Node_CustomEvent_NewRotation;  // 0x1E8(0xC)
	char pad_500[4];  // 0x1F4(0x4)
	struct AController* K2Node_Event_OldController;  // 0x1F8(0x8)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State_2;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x208(0x1)
	char pad_521[3];  // 0x209(0x3)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x20C(0xC)
	struct ASQSoldier* CallFunc_GetSoldier_ReturnValue_2;  // 0x218(0x8)
	struct ASQEquipableItem* CallFunc_GetCurrentWeapon_ReturnValue;  // 0x220(0x8)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_2;  // 0x228(0xC)
	char pad_564[4];  // 0x234(0x4)
	struct ABP_Smartphone_FPV_C* K2Node_DynamicCast_AsBP_Smartphone_FPV;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x240(0x1)
	char pad_577[3];  // 0x241(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x244(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x248(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x24C(0x4)
	struct TSoftClassPtr<UObject> CallFunc_Conv_ClassToSoftClassReference_ReturnValue;  // 0x250(0x28)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct FSQInventoryData K2Node_MakeStruct_SQInventoryData;  // 0x280(0x38)
	float CallFunc_FClamp_ReturnValue;  // 0x2B8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x2BC(0xC)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x2CC(0x88)
	char pad_852[4];  // 0x354(0x4)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State_3;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct ASQSoldier* CallFunc_GetSoldier_ReturnValue_3;  // 0x368(0x8)
	int32_t CallFunc_AddGroupToInventory_ReturnValue;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)
	struct ASQEquipableItem* CallFunc_InsertItemIntoInventory_ReturnValue;  // 0x378(0x8)
	struct ABP_Smartphone_FPV_C* K2Node_DynamicCast_AsBP_Smartphone_FPV_2;  // 0x380(0x8)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x388(0x1)
	char pad_905[7];  // 0x389(0x7)
	struct USQRoleSettings* K2Node_CustomEvent_CurrentRole;  // 0x390(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue_2;  // 0x398(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x3A4(0xC)
	float CallFunc_VSize_ReturnValue_2;  // 0x3B0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x3B4(0x4)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x3B8(0x1)
	char pad_953[3];  // 0x3B9(0x3)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x3BC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x3C0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x3C8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x3D0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x3D8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x3E4(0x88)
	float K2Node_InputAxisEvent_AxisValue;  // 0x46C(0x4)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x470(0x1)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.ReceiveUnpossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessed : public FReceiveUnpossessed
{
	struct AController* OldController;  // 0x0(0x8)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.On Possess
// Size: 0xC(Inherited: 0x0) 
struct FOn Possess
{
	struct FRotator NewRotation;  // 0x0(0xC)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Server Unpossess
// Size: 0x1(Inherited: 0x0) 
struct FServer Unpossess
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Remove : 1;  // 0x0(0x1)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_5
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveElevator_K2Node_InputAxisEvent_5
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_4
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_4
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_3
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_3
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveAileron_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpActEvt_LeanLeft_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeanLeft_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.InpActEvt_Interact_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interact_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Update Relative Rotation
// Size: 0x224(Inherited: 0x0) 
struct FUpdate Relative Rotation
{
	float NewRotationY;  // 0x0(0x4)
	float NewRotationX;  // 0x4(0x4)
	float NewRotationZ;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float Temp_float_Variable;  // 0x10(0x4)
	float Temp_float_Variable_2;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float Temp_float_Variable_3;  // 0x1C(0x4)
	float Temp_float_Variable_4;  // 0x20(0x4)
	float CallFunc_GetMaxAcceleration_ReturnValue;  // 0x24(0x4)
	float CallFunc_GetMaxSpeed_ReturnValue;  // 0x28(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_GetMaxSpeed_ReturnValue_2;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x38(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x3C(0xC)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x50(0x30)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x80(0xC)
	char pad_140[4];  // 0x8C(0x4)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x90(0x30)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue;  // 0xC0(0xC)
	float CallFunc_BreakVector_X;  // 0xCC(0x4)
	float CallFunc_BreakVector_Y;  // 0xD0(0x4)
	float CallFunc_BreakVector_Z;  // 0xD4(0x4)
	struct FVector CallFunc_GetCurrentAcceleration_ReturnValue;  // 0xD8(0xC)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue_2;  // 0xE8(0xC)
	float CallFunc_BreakVector_X_2;  // 0xF4(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xF8(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xFC(0x4)
	float K2Node_Select_Default;  // 0x100(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x104(0xC)
	float CallFunc_Abs_ReturnValue;  // 0x110(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x114(0xC)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x120(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x124(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x130(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue_2;  // 0x134(0xC)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x144(0xC)
	float CallFunc_BreakVector_X_3;  // 0x150(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x154(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x158(0x4)
	float K2Node_Select_Default_2;  // 0x15C(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x160(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x164(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x168(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_3;  // 0x16C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x170(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x174(0x4)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x178(0x88)
	float CallFunc_BreakRotator_Roll;  // 0x200(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x204(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x208(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x20C(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x210(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0x214(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x218(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x21C(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x220(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Set Can Increase Altitude
// Size: 0xC1(Inherited: 0x0) 
struct FSet Can Increase Altitude
{
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x0(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2C(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x38(0x88)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xC0(0x1)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Add Zoom Delta
// Size: 0x1C(Inherited: 0x0) 
struct FAdd Zoom Delta
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t K2Node_Select_Default;  // 0x18(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Update Zoom
// Size: 0xC(Inherited: 0x0) 
struct FUpdate Zoom
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x4(0x4)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_FlyingDrone.BP_FlyingDrone_C.Check Owner Death
// Size: 0x41(Inherited: 0x0) 
struct FCheck Owner Death
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct ASQPlayerState* K2Node_DynamicCast_AsSQPlayer_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ASQSoldier* CallFunc_GetSoldier_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x23(0x1)
	char pad_36[4];  // 0x24(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x40(0x1)

}; 
