#pragma once 
#include "SDK.h" 
 
 
// Function BP_ForwardBase.BP_ForwardBase_C.BP_OnDeployableAdded
// Size: 0x8(Inherited: 0x8) 
struct FBP_OnDeployableAdded : public FBP_OnDeployableAdded
{
	struct ASQDeployable* InDeployable;  // 0x0(0x8)

}; 
// Function BP_ForwardBase.BP_ForwardBase_C.ExecuteUbergraph_BP_ForwardBase
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ForwardBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ASQDeployable* K2Node_Event_InDeployable;  // 0x8(0x8)
	struct ASQDeployable* K2Node_Event_InDeployable_2;  // 0x10(0x8)
	struct UBP_SQDeployableSettings_C* K2Node_DynamicCast_AsBP_SQDeployable_Settings;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UBP_SQDeployableSettings_C* K2Node_DynamicCast_AsBP_SQDeployable_Settings_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)

}; 
// Function BP_ForwardBase.BP_ForwardBase_C.BP_OnDeployableRemoved
// Size: 0x8(Inherited: 0x8) 
struct FBP_OnDeployableRemoved : public FBP_OnDeployableRemoved
{
	struct ASQDeployable* InDeployable;  // 0x0(0x8)

}; 
// Function BP_ForwardBase.BP_ForwardBase_C.AddDeployable
// Size: 0x21(Inherited: 0x0) 
struct FAddDeployable
{
	char ESQDeployable InType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool L_DeployableCount_Found : 1;  // 0x1(0x1)
	struct FSQFOBDeployableCount K2Node_MakeStruct_SQFOBDeployableCount;  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x10(0x4)
	struct FSQFOBDeployableCount CallFunc_Array_Get_Item;  // 0x14(0x2)
	char pad_22[2];  // 0x16(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C(0x1)
	char CallFunc_Add_ByteByte_ReturnValue;  // 0x1D(0x1)
	struct FSQFOBDeployableCount K2Node_MakeStruct_SQFOBDeployableCount_2;  // 0x1E(0x2)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_ForwardBase.BP_ForwardBase_C.GetDeployableCount
// Size: 0x69(Inherited: 0x0) 
struct FGetDeployableCount
{
	struct TSet<char ESQDeployable> InDeployableTypes;  // 0x0(0x50)
	char OutCount;  // 0x50(0x1)
	char L_Result;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x54(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x58(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x5C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	struct FSQFOBDeployableCount CallFunc_Array_Get_Item;  // 0x64(0x2)
	char pad_102_1 : 7;  // 0x66(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x66(0x1)
	char CallFunc_Add_ByteByte_ReturnValue;  // 0x67(0x1)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Set_Contains_ReturnValue : 1;  // 0x68(0x1)

}; 
// Function BP_ForwardBase.BP_ForwardBase_C.RemoveDeployable
// Size: 0x1D(Inherited: 0x0) 
struct FRemoveDeployable
{
	char ESQDeployable InType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FSQFOBDeployableCount CallFunc_Array_Get_Item;  // 0x10(0x2)
	char pad_18[2];  // 0x12(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char CallFunc_Subtract_ByteByte_ReturnValue;  // 0x19(0x1)
	struct FSQFOBDeployableCount K2Node_MakeStruct_SQFOBDeployableCount;  // 0x1A(0x2)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1C(0x1)

}; 
