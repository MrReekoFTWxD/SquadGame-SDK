#pragma once 
#include "SDK.h" 
 
 
// Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.IsRestrictedWithFOBsInRange
// Size: 0x31(Inherited: 0x20) 
struct FIsRestrictedWithFOBsInRange : public FIsRestrictedWithFOBsInRange
{
	struct ASQPlayerController* InPlayer;  // 0x0(0x8)
	struct TArray<struct ASQForwardBase*> InFOBsInRange;  // 0x8(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	struct TArray<struct ASQForwardBase*> NewLocalVar_1;  // 0x20(0x10)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsRestrictedWithFOBsInRange_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.GetRange
// Size: 0x25(Inherited: 0x10) 
struct FGetRange : public FGetRange
{
	struct USQLayer* Layer;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	float CallFunc_GetRange_ReturnValue;  // 0xC(0x4)
	struct UBP_SQLayer_C* K2Node_DynamicCast_AsBP_SQLayer;  // 0x10(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	struct FS_FOBRadius CallFunc_GetDataTableRowFromName_OutRow;  // 0x1C(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x24(0x1)

}; 
// Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.GetRestrictionReason
// Size: 0x29(Inherited: 0x18) 
struct FGetRestrictionReason : public FGetRestrictionReason
{
	struct FDataTableRowHandle OutRestrictionReason;  // 0x0(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct FDataTableRowHandle CallFunc_GetRestrictionReason_OutRestrictionReason;  // 0x18(0x10)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_GetRestrictionReason_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.IsRestrictedForTeam
// Size: 0xB(Inherited: 0x10) 
struct FIsRestrictedForTeam : public FIsRestrictedForTeam
{
	struct ASQTeam* InTeam;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool MHQ_Found : 1;  // 0x9(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsRestrictedForTeam_ReturnValue : 1;  // 0xA(0x1)

}; 
