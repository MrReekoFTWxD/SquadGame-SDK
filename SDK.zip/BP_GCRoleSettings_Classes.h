#pragma once 
#include <BP_GCRoleSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GCRoleSettings.BP_GCRoleSettings_C
// Size: 0x205(Inherited: 0x1F8) 
struct UBP_GCRoleSettings_C : public UBP_SQRoleSettings_C
{
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CanEnterAnySeat : 1;  // 0x1F8(0x1)
	char pad_505_1 : 7;  // 0x1F9(0x1)
	bool ForceCanSeeHealthStatus : 1;  // 0x1F9(0x1)
	char pad_506[2];  // 0x1FA(0x2)
	struct FName RoleSkinName;  // 0x1FC(0x8)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool IsJumpSoldier : 1;  // 0x204(0x1)

	bool CanSeeHealthStatus(); // Function BP_GCRoleSettings.BP_GCRoleSettings_C.CanSeeHealthStatus
	bool CanEnterSeat(struct USQVehicleSeatComponent* Seat); // Function BP_GCRoleSettings.BP_GCRoleSettings_C.CanEnterSeat
}; 



