#pragma once 
#include "SDK.h" 
 
 
// Function BP_GCRoleSettings.BP_GCRoleSettings_C.CanSeeHealthStatus
// Size: 0x4(Inherited: 0x3) 
struct FCanSeeHealthStatus : public FCanSeeHealthStatus
{
	char pad_3_1 : 7;  // 0x3(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char SQRoleTags Temp_byte_Variable;  // 0x1(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Set_Contains_ReturnValue : 1;  // 0x2(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_GCRoleSettings.BP_GCRoleSettings_C.CanEnterSeat
// Size: 0xC(Inherited: 0xC) 
struct FCanEnterSeat : public FCanEnterSeat
{
	struct USQVehicleSeatComponent* Seat;  // 0x0(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x9(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xA(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xB(0x1)

}; 
