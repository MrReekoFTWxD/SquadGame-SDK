#pragma once 
#include <BP_GameStateSquad_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameStateSquad.BP_GameStateSquad_C
// Size: 0x5F8(Inherited: 0x5F0) 
struct ABP_GameStateSquad_C : public ASQGameState
{
	struct USceneComponent* DefaultSceneRoot;  // 0x5F0(0x8)

}; 



