#pragma once 
#include <BP_GameStateSquad_Seed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C
// Size: 0x640(Inherited: 0x5F8) 
struct ABP_GameStateSquad_Seed_C : public ABP_GameStateSquad_C
{
	char pad_1528_1 : 7;  // 0x5F8(0x1)
	bool bGameIsLive : 1;  // 0x5F8(0x1)
	char pad_1529[7];  // 0x5F9(0x7)
	struct FMulticastInlineDelegate OnGameIsLive;  // 0x600(0x10)
	char pad_1552_1 : 7;  // 0x610(0x1)
	bool bCountdownActive : 1;  // 0x610(0x1)
	char pad_1553[3];  // 0x611(0x3)
	float ServerTimeToFinishCountdown;  // 0x614(0x4)
	struct FMulticastInlineDelegate OnCountdownStateChanged;  // 0x618(0x10)
	int32_t PlayersThreshold;  // 0x628(0x4)
	char pad_1580[4];  // 0x62C(0x4)
	struct FMulticastInlineDelegate OnPlayerThresholdUpdated;  // 0x630(0x10)

	int32_t GetPlayerCountOnServer(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.GetPlayerCountOnServer
	void OnRep_PlayersThreshold(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnRep_PlayersThreshold
	void OnRep_ServerTimeToFinishCountdown(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnRep_ServerTimeToFinishCountdown
	void OnRep_bGameIsLive(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnRep_bGameIsLive
	void OnPlayerThresholdUpdated__DelegateSignature(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnPlayerThresholdUpdated__DelegateSignature
	void OnCountdownStateChanged__DelegateSignature(bool bIsActive, float TimeLeft); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnCountdownStateChanged__DelegateSignature
	void OnGameIsLive__DelegateSignature(); // Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnGameIsLive__DelegateSignature
}; 



