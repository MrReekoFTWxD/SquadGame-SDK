#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnCountdownStateChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCountdownStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float TimeLeft;  // 0x4(0x4)

}; 
// Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnRep_bGameIsLive
// Size: 0xB8(Inherited: 0x0) 
struct FOnRep_bGameIsLive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	struct FText Temp_text_Variable_2;  // 0x20(0x18)
	struct FText K2Node_Select_Default;  // 0x38(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x50(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x90(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xA0(0x18)

}; 
// Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.OnRep_ServerTimeToFinishCountdown
// Size: 0x11E(Inherited: 0x0) 
struct FOnRep_ServerTimeToFinishCountdown
{
	float TimeLeft;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bOldCountdownActive : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float Temp_float_Variable;  // 0x24(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x28(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x68(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x78(0x18)
	struct FText K2Node_Select_Default;  // 0x90(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0xE8(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0xF8(0x18)
	float CallFunc_GetServerWorldTimeSeconds_ReturnValue;  // 0x110(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x114(0x4)
	float K2Node_Select_Default_2;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x11C(0x1)
	char pad_285_1 : 7;  // 0x11D(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x11D(0x1)

}; 
// Function BP_GameStateSquad_Seed.BP_GameStateSquad_Seed_C.GetPlayerCountOnServer
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerCountOnServer
{
	int32_t ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)

}; 
