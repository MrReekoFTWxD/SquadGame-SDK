#pragma once 
#include "SDK.h" 
 
 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__TailBladesCollision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__TailBladesCollision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ExecuteUbergraph_BP_Generic_Helicopter
// Size: 0xD68(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Generic_Helicopter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_CanLand_CanLand_ : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_CustomEvent_IsLanded_ : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	float K2Node_CustomEvent_AxisInput;  // 0x1C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue_2 : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool K2Node_CustomEvent_NewIsLandedState : 1;  // 0x2F(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x30(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x34(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_2 : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float K2Node_CustomEvent_AxisValue_3;  // 0x40(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	float CallFunc_Abs_ReturnValue_2;  // 0x4C(0x4)
	float CallFunc_BreakVector_X;  // 0x50(0x4)
	float CallFunc_BreakVector_Y;  // 0x54(0x4)
	float CallFunc_BreakVector_Z;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_3 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x5E(0x1)
	char pad_95[1];  // 0x5F(0x1)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x60(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x6C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x70(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x74(0x4)
	float K2Node_CustomEvent_AxisValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x80(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_5;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_4 : 1;  // 0x9A(0x1)
	char pad_155_1 : 7;  // 0x9B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9B(0x1)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct FKey K2Node_InputActionEvent_Key_10;  // 0xA0(0x18)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue : 1;  // 0xBB(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float K2Node_CustomEvent_AxisValue;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue_2 : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_6 : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_6;  // 0xCC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_7;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	float CallFunc_GetRollNormalized_NewParam;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0xDC(0x1)
	char pad_221_1 : 7;  // 0xDD(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xDD(0x1)
	char pad_222[2];  // 0xDE(0x2)
	float CallFunc_Abs_ReturnValue_3;  // 0xE0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0xEC(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	float Temp_float_Variable;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xFC(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xFD(0x1)
	char pad_254_1 : 7;  // 0xFE(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_4 : 1;  // 0xFE(0x1)
	char pad_255[1];  // 0xFF(0x1)
	float K2Node_InputAxisEvent_AxisValue_15;  // 0x100(0x4)
	float K2Node_InputAxisEvent_AxisValue_14;  // 0x104(0x4)
	float K2Node_InputAxisEvent_AxisValue_13;  // 0x108(0x4)
	float K2Node_InputAxisEvent_AxisValue_12;  // 0x10C(0x4)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_GetIsUsingFreeLook_ReturnValue : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_GetIsUsingFreeLook_ReturnValue_2 : 1;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x120(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_2;  // 0x128(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x130(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x134(0x4)
	struct FKey K2Node_InputActionEvent_Key_9;  // 0x138(0x18)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_IsHealthy_ReturnValue : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue_2 : 1;  // 0x152(0x1)
	char pad_339[1];  // 0x153(0x1)
	float CallFunc_GetThrustPower_Thrust;  // 0x154(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x158(0x4)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_4 : 1;  // 0x15C(0x1)
	char pad_349[3];  // 0x15D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0x160(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_10;  // 0x164(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_8;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_HasAuthority_ReturnValue_5 : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	float CallFunc_FInterpTo_ReturnValue;  // 0x170(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x174(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x178(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x17C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_11;  // 0x180(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_9;  // 0x184(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x188(0x4)
	char pad_396_1 : 7;  // 0x18C(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_3 : 1;  // 0x18C(0x1)
	char pad_397_1 : 7;  // 0x18D(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x18D(0x1)
	char pad_398_1 : 7;  // 0x18E(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x18E(0x1)
	char pad_399_1 : 7;  // 0x18F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x18F(0x1)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x194(0x4)
	float CallFunc_FInterpTo_ReturnValue_3;  // 0x198(0x4)
	float K2Node_CustomEvent_DeltaTimeRatio;  // 0x19C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_5;  // 0x1A0(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x1A4(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x1A8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_12;  // 0x1AC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_13;  // 0x1B0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_14;  // 0x1B4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_15;  // 0x1B8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_16;  // 0x1BC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_10;  // 0x1C0(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x1C4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_6;  // 0x1C8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_17;  // 0x1CC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_18;  // 0x1D0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_19;  // 0x1D4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_20;  // 0x1D8(0x4)
	char pad_476[4];  // 0x1DC(0x4)
	struct FKey K2Node_InputActionEvent_Key_8;  // 0x1E0(0x18)
	struct FKey Temp_struct_Variable;  // 0x1F8(0x18)
	float K2Node_InputAxisEvent_AxisValue_11;  // 0x210(0x4)
	char pad_532_1 : 7;  // 0x214(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_4 : 1;  // 0x214(0x1)
	char pad_533_1 : 7;  // 0x215(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x215(0x1)
	char pad_534[2];  // 0x216(0x2)
	float K2Node_InputAxisEvent_AxisValue_10;  // 0x218(0x4)
	float K2Node_InputAxisEvent_AxisValue_9;  // 0x21C(0x4)
	float K2Node_InputAxisEvent_AxisValue_8;  // 0x220(0x4)
	char pad_548_1 : 7;  // 0x224(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_5 : 1;  // 0x224(0x1)
	char pad_549_1 : 7;  // 0x225(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_6 : 1;  // 0x225(0x1)
	char pad_550_1 : 7;  // 0x226(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x226(0x1)
	char pad_551_1 : 7;  // 0x227(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x227(0x1)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_3 : 1;  // 0x229(0x1)
	char pad_554_1 : 7;  // 0x22A(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x22A(0x1)
	char pad_555_1 : 7;  // 0x22B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x22B(0x1)
	char pad_556[4];  // 0x22C(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_3;  // 0x230(0x8)
	struct FSQJoyStickConfig CallFunc_GetJoyConfig_ReturnValue;  // 0x238(0x10)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_4;  // 0x248(0x8)
	float CallFunc_CurveType_Out;  // 0x250(0x4)
	struct FSQJoyStickConfig CallFunc_GetJoyConfig_ReturnValue_2;  // 0x254(0x10)
	float CallFunc_CurveType_Out_2;  // 0x264(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_5;  // 0x268(0x8)
	struct FSQJoyStickConfig CallFunc_GetJoyConfig_ReturnValue_3;  // 0x270(0x10)
	float CallFunc_CurveType_Out_3;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_6;  // 0x288(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_7;  // 0x290(0x8)
	float K2Node_InputAxisEvent_AxisValue_7;  // 0x298(0x4)
	float Temp_float_Variable_2;  // 0x29C(0x4)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue_3 : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	float K2Node_InputAxisEvent_AxisValue_6;  // 0x2A4(0x4)
	float K2Node_InputAxisEvent_AxisValue_5;  // 0x2A8(0x4)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x2AC(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x2B0(0x8)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x2B8(0x1)
	char pad_697[3];  // 0x2B9(0x3)
	float CallFunc_Abs_ReturnValue_4;  // 0x2BC(0x4)
	float CallFunc_Abs_ReturnValue_5;  // 0x2C0(0x4)
	float CallFunc_Abs_ReturnValue_6;  // 0x2C4(0x4)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	float CallFunc_Abs_ReturnValue_7;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	float CallFunc_Abs_ReturnValue_8;  // 0x2D4(0x4)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_5 : 1;  // 0x2D8(0x1)
	char pad_729[3];  // 0x2D9(0x3)
	float CallFunc_Abs_ReturnValue_9;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_6 : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_4 : 1;  // 0x2E1(0x1)
	char pad_738_1 : 7;  // 0x2E2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_7 : 1;  // 0x2E2(0x1)
	char pad_739_1 : 7;  // 0x2E3(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x2E3(0x1)
	char pad_740_1 : 7;  // 0x2E4(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x2E4(0x1)
	char pad_741_1 : 7;  // 0x2E5(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x2E5(0x1)
	char pad_742[2];  // 0x2E6(0x2)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller;  // 0x2E8(0x8)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_2;  // 0x2F8(0x8)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x301(0x1)
	char pad_770[6];  // 0x302(0x6)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_3;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_4;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool Temp_bool_Variable : 1;  // 0x321(0x1)
	char pad_802_1 : 7;  // 0x322(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0x322(0x1)
	char pad_803[1];  // 0x323(0x1)
	float K2Node_Select_Default;  // 0x324(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_21;  // 0x328(0x4)
	char pad_812_1 : 7;  // 0x32C(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0x32C(0x1)
	char pad_813[3];  // 0x32D(0x3)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_5;  // 0x330(0x8)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_6;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x348(0x1)
	char pad_841_1 : 7;  // 0x349(0x1)
	bool CallFunc_HasAuthority_ReturnValue_6 : 1;  // 0x349(0x1)
	char pad_842_1 : 7;  // 0x34A(0x1)
	bool CallFunc_IsValid_ReturnValue_16 : 1;  // 0x34A(0x1)
	char pad_843_1 : 7;  // 0x34B(0x1)
	bool CallFunc_IsValid_ReturnValue_17 : 1;  // 0x34B(0x1)
	char pad_844[4];  // 0x34C(0x4)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_7;  // 0x350(0x8)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x358(0x1)
	char pad_857[7];  // 0x359(0x7)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller_8;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool CallFunc_GetIsUsingFreeLook_ReturnValue_3 : 1;  // 0x369(0x1)
	char pad_874[2];  // 0x36A(0x2)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x36C(0x4)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x370(0x4)
	char pad_884_1 : 7;  // 0x374(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue_4 : 1;  // 0x374(0x1)
	char pad_885[3];  // 0x375(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_22;  // 0x378(0x4)
	char pad_892[4];  // 0x37C(0x4)
	struct FKey K2Node_InputActionEvent_Key_7;  // 0x380(0x18)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool CallFunc_IsActive_ReturnValue : 1;  // 0x398(0x1)
	char pad_921_1 : 7;  // 0x399(0x1)
	bool CallFunc_BooleanAND_ReturnValue_8 : 1;  // 0x399(0x1)
	char pad_922[2];  // 0x39A(0x2)
	float CallFunc_BreakRotator_Roll_2;  // 0x39C(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x3A0(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x3A4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_11;  // 0x3A8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x3AC(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x3B8(0x88)
	float CallFunc_BreakRotator_Roll_3;  // 0x440(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x444(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x448(0x4)
	char pad_1100[4];  // 0x44C(0x4)
	struct AController* K2Node_Event_NewController;  // 0x450(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue_12;  // 0x458(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x45C(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x468(0x88)
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_7 : 1;  // 0x4F0(0x1)
	char pad_1265[7];  // 0x4F1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x4F8(0x8)
	struct AController* K2Node_Event_OldController;  // 0x500(0x8)
	char pad_1288_1 : 7;  // 0x508(0x1)
	bool K2Node_CustomEvent_IgnoreLandingCheck : 1;  // 0x508(0x1)
	char pad_1289[3];  // 0x509(0x3)
	struct FVector K2Node_CustomEvent_NewLinearVelocity;  // 0x50C(0xC)
	struct FVector K2Node_CustomEvent_NewAngularVelocity;  // 0x518(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x524(0x4)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_8 : 1;  // 0x528(0x1)
	char pad_1321_1 : 7;  // 0x529(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_5 : 1;  // 0x529(0x1)
	char pad_1322_1 : 7;  // 0x52A(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x52A(0x1)
	char pad_1323_1 : 7;  // 0x52B(0x1)
	bool CallFunc_IsValid_ReturnValue_18 : 1;  // 0x52B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x52C(0x10)
	char pad_1340[4];  // 0x53C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x540(0x8)
	uint8_t  Temp_byte_Variable;  // 0x548(0x1)
	char pad_1353[3];  // 0x549(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x54C(0x10)
	char pad_1372[4];  // 0x55C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_3;  // 0x560(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x568(0x4)
	char pad_1388_1 : 7;  // 0x56C(0x1)
	bool CallFunc_HasAuthority_ReturnValue_7 : 1;  // 0x56C(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x56D(0x1)
	char pad_1390[2];  // 0x56E(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue_23;  // 0x570(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_24;  // 0x574(0x4)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x578(0x1)
	char pad_1401[3];  // 0x579(0x3)
	float CallFunc_VSize_ReturnValue_2;  // 0x57C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_25;  // 0x580(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x584(0x4)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x588(0xC)
	float CallFunc_FClamp_ReturnValue_4;  // 0x594(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x598(0xC)
	float CallFunc_VSize_ReturnValue_3;  // 0x5A4(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x5A8(0xC)
	char pad_1460[4];  // 0x5B4(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x5B8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x5C8(0x10)
	struct FVector CallFunc_CalcCustomVelocity_Velocity;  // 0x5D8(0xC)
	char pad_1508[4];  // 0x5E4(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x5E8(0x10)
	uint8_t  K2Node_Select_Default_2;  // 0x5F8(0x1)
	char pad_1529_1 : 7;  // 0x5F9(0x1)
	bool CallFunc_CanLand_CanLand__2 : 1;  // 0x5F9(0x1)
	char pad_1530_1 : 7;  // 0x5FA(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue_3 : 1;  // 0x5FA(0x1)
	char pad_1531_1 : 7;  // 0x5FB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_9 : 1;  // 0x5FB(0x1)
	char pad_1532_1 : 7;  // 0x5FC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_10 : 1;  // 0x5FC(0x1)
	char pad_1533_1 : 7;  // 0x5FD(0x1)
	bool CallFunc_CanLand_CanLand__3 : 1;  // 0x5FD(0x1)
	char pad_1534[2];  // 0x5FE(0x2)
	float CallFunc_GetGradualRotationIncrement_Roll;  // 0x600(0x4)
	float CallFunc_GetGradualRotationIncrement_Pitch;  // 0x604(0x4)
	char pad_1544_1 : 7;  // 0x608(0x1)
	bool K2Node_CustomEvent_bActive : 1;  // 0x608(0x1)
	char pad_1545[3];  // 0x609(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x60C(0x10)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x61C(0xC)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x628(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_3;  // 0x630(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_3;  // 0x638(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x640(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x64C(0x88)
	struct FRotator CallFunc_GetRotationDiff_NewParam;  // 0x6D4(0xC)
	char pad_1760_1 : 7;  // 0x6E0(0x1)
	bool CallFunc_BooleanAND_ReturnValue_9 : 1;  // 0x6E0(0x1)
	char pad_1761[3];  // 0x6E1(0x3)
	float K2Node_InputAxisEvent_AxisValue;  // 0x6E4(0x4)
	float CallFunc_Abs_ReturnValue_10;  // 0x6E8(0x4)
	char pad_1772_1 : 7;  // 0x6EC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_6 : 1;  // 0x6EC(0x1)
	char pad_1773[3];  // 0x6ED(0x3)
	float CallFunc_SetGroundEffect_Height;  // 0x6F0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x6F4(0x4)
	struct ASQSoldier* K2Node_Event_Soldier_3;  // 0x6F8(0x8)
	struct USQVehicleSeatComponent* K2Node_Event_NewSeat_2;  // 0x700(0x8)
	char pad_1800_1 : 7;  // 0x708(0x1)
	bool CallFunc_HasAuthority_ReturnValue_8 : 1;  // 0x708(0x1)
	char pad_1801_1 : 7;  // 0x709(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_5 : 1;  // 0x709(0x1)
	char pad_1802[6];  // 0x70A(0x6)
	struct ASQSoldier* K2Node_Event_Soldier_2;  // 0x710(0x8)
	struct USQVehicleSeatComponent* K2Node_Event_PreviousSeat_2;  // 0x718(0x8)
	struct USQVehicleSeatComponent* K2Node_Event_NewSeat;  // 0x720(0x8)
	char pad_1832_1 : 7;  // 0x728(0x1)
	bool CallFunc_IsActive_ReturnValue_2 : 1;  // 0x728(0x1)
	char pad_1833_1 : 7;  // 0x729(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_6 : 1;  // 0x729(0x1)
	char pad_1834[2];  // 0x72A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x72C(0x10)
	char pad_1852[4];  // 0x73C(0x4)
	struct AWorldSettings* CallFunc_GetWorldSettings_ReturnValue;  // 0x740(0x8)
	char pad_1864_1 : 7;  // 0x748(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue_5 : 1;  // 0x748(0x1)
	char pad_1865[7];  // 0x749(0x7)
	struct ASQWorldSettings* K2Node_DynamicCast_AsSQWorld_Settings;  // 0x750(0x8)
	char pad_1880_1 : 7;  // 0x758(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x758(0x1)
	char pad_1881_1 : 7;  // 0x759(0x1)
	bool K2Node_CustomEvent_Condition : 1;  // 0x759(0x1)
	char pad_1882[2];  // 0x75A(0x2)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x75C(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x760(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x768(0x8)
	char pad_1904_1 : 7;  // 0x770(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x770(0x1)
	char pad_1905_1 : 7;  // 0x771(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x771(0x1)
	char pad_1906_1 : 7;  // 0x772(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x772(0x1)
	char pad_1907_1 : 7;  // 0x773(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x773(0x1)
	char pad_1908[4];  // 0x774(0x4)
	struct ASQSoldier* K2Node_Event_Soldier;  // 0x778(0x8)
	struct USQVehicleSeatComponent* K2Node_Event_PreviousSeat;  // 0x780(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x788(0x8)
	char pad_1936_1 : 7;  // 0x790(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_3 : 1;  // 0x790(0x1)
	char pad_1937_1 : 7;  // 0x791(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_7 : 1;  // 0x791(0x1)
	char pad_1938_1 : 7;  // 0x792(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0x792(0x1)
	char pad_1939[5];  // 0x793(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_5;  // 0x798(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x7A0(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x7A8(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x7AC(0x10)
	char pad_1980[4];  // 0x7BC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_4;  // 0x7C0(0x8)
	float CallFunc_GetMainRotorThrust_ReturnValue;  // 0x7C8(0x4)
	char pad_1996_1 : 7;  // 0x7CC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_7 : 1;  // 0x7CC(0x1)
	char pad_1997[3];  // 0x7CD(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x7D0(0x10)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool K2Node_Event_Active : 1;  // 0x7E0(0x1)
	char pad_2017[7];  // 0x7E1(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_5;  // 0x7E8(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x7F0(0x88)
	float K2Node_CustomEvent_TimeSlice;  // 0x878(0x4)
	struct FVector K2Node_CustomEvent_MoveDelta;  // 0x87C(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0x888(0x10)
	struct FKey K2Node_InputActionEvent_Key;  // 0x898(0x18)
	float CallFunc_GetThrustPower_Thrust_2;  // 0x8B0(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_7;  // 0x8B4(0x4)
	float CallFunc_GetTimeSeconds_ReturnValue;  // 0x8B8(0x4)
	float CallFunc_Abs_ReturnValue_11;  // 0x8BC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_13;  // 0x8C0(0x4)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0x8C4(0xC)
	char pad_2256_1 : 7;  // 0x8D0(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_5 : 1;  // 0x8D0(0x1)
	char pad_2257_1 : 7;  // 0x8D1(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_6 : 1;  // 0x8D1(0x1)
	char pad_2258_1 : 7;  // 0x8D2(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_7 : 1;  // 0x8D2(0x1)
	char pad_2259_1 : 7;  // 0x8D3(0x1)
	bool CallFunc_BooleanOR_ReturnValue_6 : 1;  // 0x8D3(0x1)
	char pad_2260_1 : 7;  // 0x8D4(0x1)
	bool CallFunc_BooleanOR_ReturnValue_7 : 1;  // 0x8D4(0x1)
	char pad_2261_1 : 7;  // 0x8D5(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0x8D5(0x1)
	char pad_2262_1 : 7;  // 0x8D6(0x1)
	bool CallFunc_BooleanOR_ReturnValue_8 : 1;  // 0x8D6(0x1)
	char pad_2263[1];  // 0x8D7(0x1)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x8D8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8E4(0xC)
	char pad_2288_1 : 7;  // 0x8F0(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x8F0(0x1)
	char pad_2289[3];  // 0x8F1(0x3)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x8F4(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x900(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x90C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x918(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_26;  // 0x924(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x928(0xC)
	float CallFunc_VSize_ReturnValue_4;  // 0x934(0x4)
	float CallFunc_VSize_ReturnValue_5;  // 0x938(0x4)
	char pad_2364[4];  // 0x93C(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_2;  // 0x940(0x10)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_3;  // 0x950(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x960(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x970(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x980(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x990(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_7;  // 0x9A0(0x10)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x9B0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x9BC(0xC)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x9C8(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x9D4(0xC)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue_2;  // 0x9E0(0xC)
	float CallFunc_VSize_ReturnValue_6;  // 0x9EC(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_4;  // 0x9F0(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xA00(0xC)
	char pad_2572[4];  // 0xA0C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_8;  // 0xA10(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_9;  // 0xA20(0x10)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0xA30(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0xA3C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_5;  // 0xA48(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_5;  // 0xA54(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_6;  // 0xA60(0xC)
	char pad_2668[4];  // 0xA6C(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_5;  // 0xA70(0x10)
	struct FKey Temp_struct_Variable_2;  // 0xA80(0x18)
	struct FString CallFunc_Concat_StrStr_ReturnValue_10;  // 0xA98(0x10)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0xAA8(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0xAC0(0x18)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0xAD8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xADC(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_8;  // 0xAE0(0x8)
	char pad_2792_1 : 7;  // 0xAE8(0x1)
	bool CallFunc_EqualEqual_BoolBool_ReturnValue : 1;  // 0xAE8(0x1)
	char pad_2793[3];  // 0xAE9(0x3)
	float CallFunc_GetNormalizedHealth_ReturnValue;  // 0xAEC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_27;  // 0xAF0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_28;  // 0xAF4(0x4)
	char pad_2808_1 : 7;  // 0xAF8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_4 : 1;  // 0xAF8(0x1)
	char pad_2809[7];  // 0xAF9(0x7)
	struct FKey Temp_struct_Variable_3;  // 0xB00(0x18)
	char pad_2840_1 : 7;  // 0xB18(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_11 : 1;  // 0xB18(0x1)
	char pad_2841_1 : 7;  // 0xB19(0x1)
	bool CallFunc_IsEngineActive_ReturnValue : 1;  // 0xB19(0x1)
	char pad_2842[2];  // 0xB1A(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue_29;  // 0xB1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_30;  // 0xB20(0x4)
	char pad_2852_1 : 7;  // 0xB24(0x1)
	bool CallFunc_HasAuthority_ReturnValue_9 : 1;  // 0xB24(0x1)
	char pad_2853_1 : 7;  // 0xB25(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_8 : 1;  // 0xB25(0x1)
	char pad_2854[2];  // 0xB26(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0xB28(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_6;  // 0xB38(0x8)
	float CallFunc_ApplyDamage_ReturnValue;  // 0xB40(0x4)
	char pad_2884[4];  // 0xB44(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0xB48(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0xB50(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0xB58(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0xB60(0x4)
	char pad_2916_1 : 7;  // 0xB64(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_2 : 1;  // 0xB64(0x1)
	char pad_2917[3];  // 0xB65(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_2;  // 0xB68(0x88)
	AActor* CallFunc_GetObjectClass_ReturnValue;  // 0xBF0(0x8)
	char pad_3064_1 : 7;  // 0xBF8(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue : 1;  // 0xBF8(0x1)
	char pad_3065[7];  // 0xBF9(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0xC00(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xC08(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xC10(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0xC18(0x4)
	char pad_3100_1 : 7;  // 0xC1C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0xC1C(0x1)
	char pad_3101[3];  // 0xC1D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0xC20(0x88)
	AActor* CallFunc_GetObjectClass_ReturnValue_2;  // 0xCA8(0x8)
	char pad_3248_1 : 7;  // 0xCB0(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue_2 : 1;  // 0xCB0(0x1)
	char pad_3249[3];  // 0xCB1(0x3)
	float CallFunc_GetKnots_Knots;  // 0xCB4(0x4)
	float CallFunc_GetKnots_Knots_2;  // 0xCB8(0x4)
	char pad_3260_1 : 7;  // 0xCBC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_8 : 1;  // 0xCBC(0x1)
	char pad_3261[3];  // 0xCBD(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0xCC0(0x10)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0xCD0(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_4;  // 0xCE8(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0xCF4(0x10)
	float CallFunc_GetWaterDepth_Depth;  // 0xD04(0x4)
	char pad_3336_1 : 7;  // 0xD08(0x1)
	bool CallFunc_GetWaterDepth_ReturnValue : 1;  // 0xD08(0x1)
	char pad_3337[3];  // 0xD09(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_5;  // 0xD0C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_31;  // 0xD10(0x4)
	float CallFunc_FMax_ReturnValue;  // 0xD14(0x4)
	float CallFunc_ApplyDamage_ReturnValue_2;  // 0xD18(0x4)
	char pad_3356[4];  // 0xD1C(0x4)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0xD20(0x18)
	struct FKey Temp_struct_Variable_4;  // 0xD38(0x18)
	struct FKey K2Node_InputActionEvent_Key_6;  // 0xD50(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddRoll
// Size: 0x20(Inherited: 0x0) 
struct FAddRoll
{
	float Roll_;  // 0x0(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x4(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x8(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x10(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x14(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddYaw
// Size: 0x20(Inherited: 0x0) 
struct FAddYaw
{
	float Yaw;  // 0x0(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x4(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x8(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x10(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x14(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Set Landing Camera
// Size: 0x1(Inherited: 0x0) 
struct FSet Landing Camera
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Active : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropAmmo_K2Node_InputActionEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_DropAmmo_K2Node_InputActionEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_Helicopter_Recenter_View_K2Node_InputActionEvent_10
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Helicopter_Recenter_View_K2Node_InputActionEvent_10
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Look_Up_Down_K2Node_InputAxisEvent_3
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Helicopter_Look_Up_Down_K2Node_InputAxisEvent_3
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__MainBladesCollision_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__MainBladesCollision_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnFDMImpact
// Size: 0x98(Inherited: 0x0) 
struct FOnFDMImpact
{
	struct FHitResult HitResult;  // 0x0(0x88)
	float TimeSlice;  // 0x88(0x4)
	struct FVector MoveDelta;  // 0x8C(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Manage Landing Camera
// Size: 0xB0(Inherited: 0x0) 
struct FManage Landing Camera
{
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x0(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x14(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Is_Using_Landing_Camera_Using_Landing_Camera : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x28(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Pitch
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput_Pitch
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.LeftVehicle
// Size: 0x10(Inherited: 0x10) 
struct FLeftVehicle : public FLeftVehicle
{
	struct ASQSoldier* Soldier;  // 0x0(0x8)
	struct USQVehicleSeatComponent* PreviousSeat;  // 0x8(0x8)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Toggle Landing Camera
// Size: 0x1(Inherited: 0x0) 
struct FToggle Landing Camera
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Condition : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRollToYawTransfer
// Size: 0x14(Inherited: 0x0) 
struct FDoRollToYawTransfer
{
	float CallFunc_GetRollNormalized_NewParam;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x10(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.SwitchedSeat
// Size: 0x18(Inherited: 0x18) 
struct FSwitchedSeat : public FSwitchedSeat
{
	struct ASQSoldier* Soldier;  // 0x0(0x8)
	struct USQVehicleSeatComponent* PreviousSeat;  // 0x8(0x8)
	struct USQVehicleSeatComponent* NewSeat;  // 0x10(0x8)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.EnteredVehicle
// Size: 0x10(Inherited: 0x10) 
struct FEnteredVehicle : public FEnteredVehicle
{
	struct ASQSoldier* Soldier;  // 0x0(0x8)
	struct USQVehicleSeatComponent* NewSeat;  // 0x8(0x8)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_VehicleZoom_K2Node_InputAxisEvent_9
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_VehicleZoom_K2Node_InputAxisEvent_9
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__VehicleMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__VehicleMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddAcceleration
// Size: 0x48(Inherited: 0x0) 
struct FAddAcceleration
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x8(0x8)
	struct FSQJoyStickConfig CallFunc_GetJoyConfig_ReturnValue;  // 0x10(0x10)
	float CallFunc_CurveType_Out;  // 0x20(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x30(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x38(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x3C(0x4)
	float K2Node_Select_Default;  // 0x40(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x44(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropAmmo_K2Node_InputActionEvent_9
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_DropAmmo_K2Node_InputActionEvent_9
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnEngineActive
// Size: 0x1(Inherited: 0x0) 
struct FOnEngineActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupConstruct_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PickupConstruct_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.TurnOnPhysics
// Size: 0x1C(Inherited: 0x0) 
struct FTurnOnPhysics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IgnoreLandingCheck : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector NewLinearVelocity;  // 0x4(0xC)
	struct FVector NewAngularVelocity;  // 0x10(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_3
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveAileron_K2Node_InputAxisEvent_3
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveUnpossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessed : public FReceiveUnpossessed
{
	struct AController* OldController;  // 0x0(0x8)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupConstruct_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PickupConstruct_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_14
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUp_K2Node_InputAxisEvent_14
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_8
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Turn_K2Node_InputAxisEvent_8
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterRollKey_K2Node_InputAxisEvent_6
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterRollKey_K2Node_InputAxisEvent_6
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Look_Right_Left_K2Node_InputAxisEvent_5
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Helicopter_Look_Right_Left_K2Node_InputAxisEvent_5
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoPushAndBounce
// Size: 0x4A(Inherited: 0x0) 
struct FDoPushAndBounce
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	float CallFunc_FInterpTo_ReturnValue;  // 0x18(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x1C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x28(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x30(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x34(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x38(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x3C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x40(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x49(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterPitchKey_K2Node_InputAxisEvent_7
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterPitchKey_K2Node_InputAxisEvent_7
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PolishRollInput
// Size: 0x84(Inherited: 0x0) 
struct FPolishRollInput
{
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_GetThrustPower_Thrust;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x10(0x4)
	float CallFunc_GetRollNormalized_NewParam;  // 0x14(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x18(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x24(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x28(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x34(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x38(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x3C(0x4)
	float Temp_float_Variable;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	float CallFunc_Abs_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x50(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x54(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Temp_bool_Variable : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	float CallFunc_GetDistanceFromTheGround_Distance;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_GetDistanceFromTheGround_GotDistance : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x68(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x6C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x70(0x4)
	float CallFunc_FClamp_ReturnValue_4;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float K2Node_Select_Default;  // 0x7C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0x80(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Yaw_K2Node_InputAxisEvent_12
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterCyclic_Yaw_K2Node_InputAxisEvent_12
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CanLand
// Size: 0x34D(Inherited: 0x0) 
struct FCanLand
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanLand? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	struct TArray<struct AActor*> Temp_object_Variable_2;  // 0x18(0x10)
	struct TArray<struct AActor*> Temp_object_Variable_3;  // 0x28(0x10)
	struct TArray<struct AActor*> Temp_object_Variable_4;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x4C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x58(0x4)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x5C(0xC)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x6C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x78(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x84(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_2;  // 0x90(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x9C(0x88)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x128(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x134(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x140(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_3;  // 0x14C(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit_2;  // 0x158(0x88)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue_2 : 1;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x1E4(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x1F0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x1FC(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit_3;  // 0x208(0x88)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue_3 : 1;  // 0x290(0x1)
	char pad_657[3];  // 0x291(0x3)
	struct FVector CallFunc_GetForwardVector_ReturnValue_4;  // 0x294(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0x2A0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_4;  // 0x2AC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x2B8(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit_4;  // 0x2C4(0x88)
	char pad_844_1 : 7;  // 0x34C(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue_4 : 1;  // 0x34C(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Roll_K2Node_InputAxisEvent_11
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterCyclic_Roll_K2Node_InputAxisEvent_11
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcCustomVelocity
// Size: 0x4A4(Inherited: 0x0) 
struct FCalcCustomVelocity
{
	struct FVector Velocity;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TMap<struct FString, struct FString> DebugVars;  // 0x10(0x50)
	float L_YDirection;  // 0x60(0x4)
	float L_XDirection;  // 0x64(0x4)
	float L_ZDirection;  // 0x68(0x4)
	float L_AccelerationValue;  // 0x6C(0x4)
	float L_RollPercent;  // 0x70(0x4)
	float L_RollDirection;  // 0x74(0x4)
	float L_PitchNormal;  // 0x78(0x4)
	float L_RolllNormal;  // 0x7C(0x4)
	struct FVector L_CurrentVector;  // 0x80(0xC)
	char pad_140[4];  // 0x8C(0x4)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x90(0x30)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0xC0(0xC)
	float CallFunc_VSize_ReturnValue;  // 0xCC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xD0(0x4)
	struct FVector CallFunc_GetVectorValue_ReturnValue;  // 0xD4(0xC)
	float CallFunc_BreakVector_X;  // 0xE0(0x4)
	float CallFunc_BreakVector_Y;  // 0xE4(0x4)
	float CallFunc_BreakVector_Z;  // 0xE8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xEC(0x4)
	float CallFunc_BreakVector_X_2;  // 0xF0(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xF4(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xFC(0x4)
	float CallFunc_BreakVector_X_3;  // 0x100(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x104(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x108(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x10C(0x4)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float CallFunc_GetPitchNormalized_NewParam;  // 0x114(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x118(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x11C(0x4)
	float CallFunc_GetRollNormalized_NewParam;  // 0x120(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x124(0x4)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x128(0x1)
	char pad_297[3];  // 0x129(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x12C(0x4)
	struct FVector CallFunc_GetVectorValue_ReturnValue_2;  // 0x130(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x13C(0x4)
	float CallFunc_BreakVector_X_4;  // 0x140(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x144(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x148(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x14C(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x158(0xC)
	float CallFunc_BreakVector_X_5;  // 0x164(0x4)
	float CallFunc_BreakVector_Y_5;  // 0x168(0x4)
	float CallFunc_BreakVector_Z_5;  // 0x16C(0x4)
	struct FRotator CallFunc_NegateRotator_ReturnValue;  // 0x170(0xC)
	char pad_380_1 : 7;  // 0x17C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x17C(0x1)
	char pad_381[3];  // 0x17D(0x3)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x180(0x10)
	float CallFunc_SelectFloat_ReturnValue_2;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x198(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x1A8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x1AC(0xC)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0x1B8(0xC)
	float CallFunc_GetMainRotorThrust_ReturnValue;  // 0x1C4(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x1C8(0xC)
	float CallFunc_GetThrustPower_Thrust;  // 0x1D4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x1D8(0x4)
	char pad_476[4];  // 0x1DC(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x1E0(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x1F0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x1F4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x1F8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0x1FC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_10;  // 0x200(0x4)
	float CallFunc_BreakVector_X_6;  // 0x204(0x4)
	float CallFunc_BreakVector_Y_6;  // 0x208(0x4)
	float CallFunc_BreakVector_Z_6;  // 0x20C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_11;  // 0x210(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x214(0x4)
	float CallFunc_BreakVector_X_7;  // 0x218(0x4)
	float CallFunc_BreakVector_Y_7;  // 0x21C(0x4)
	float CallFunc_BreakVector_Z_7;  // 0x220(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x224(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x230(0xC)
	float CallFunc_BreakVector_X_8;  // 0x23C(0x4)
	float CallFunc_BreakVector_Y_8;  // 0x240(0x4)
	float CallFunc_BreakVector_Z_8;  // 0x244(0x4)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x24C(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x250(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_4;  // 0x254(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x260(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x26C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x278(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x284(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x290(0x88)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x318(0x1)
	char pad_793_1 : 7;  // 0x319(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x319(0x1)
	char pad_794_1 : 7;  // 0x31A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x31A(0x1)
	char pad_795[1];  // 0x31B(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x31C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x320(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x324(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x330(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x33C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x348(0xC)
	char pad_852[4];  // 0x354(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x358(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x360(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x368(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x370(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x378(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x37C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x380(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x384(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x390(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x39C(0xC)
	float CallFunc_VSize_ReturnValue_2;  // 0x3A8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_12;  // 0x3AC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_5;  // 0x3B0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x3BC(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_13;  // 0x3C8(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x3CC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_6;  // 0x3D0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x3DC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x3E8(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x3F4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x3F8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_14;  // 0x3FC(0x4)
	float CallFunc_GetFloatValue_ReturnValue_2;  // 0x400(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_15;  // 0x404(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x408(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_16;  // 0x40C(0x4)
	float CallFunc_GetMainRotorThrust_ReturnValue_2;  // 0x410(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_17;  // 0x414(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_18;  // 0x418(0x4)
	float CallFunc_BreakVector_X_9;  // 0x41C(0x4)
	float CallFunc_BreakVector_Y_9;  // 0x420(0x4)
	float CallFunc_BreakVector_Z_9;  // 0x424(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_19;  // 0x428(0x4)
	float CallFunc_GetFloatValue_ReturnValue_3;  // 0x42C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_20;  // 0x430(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x434(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_7;  // 0x438(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_21;  // 0x444(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x448(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_8;  // 0x44C(0xC)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue;  // 0x458(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x464(0xC)
	float CallFunc_BreakVector_X_10;  // 0x470(0x4)
	float CallFunc_BreakVector_Y_10;  // 0x474(0x4)
	float CallFunc_BreakVector_Z_10;  // 0x478(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_5;  // 0x47C(0xC)
	float CallFunc_FInterpTo_ReturnValue_3;  // 0x488(0x4)
	float CallFunc_FInterpTo_ReturnValue_4;  // 0x48C(0x4)
	float CallFunc_FInterpTo_ReturnValue_5;  // 0x490(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_9;  // 0x494(0xC)
	float CallFunc_GetFloatValue_ReturnValue_4;  // 0x4A0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Pitch_K2Node_InputAxisEvent_10
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterCyclic_Pitch_K2Node_InputAxisEvent_10
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropConstruct_K2Node_InputActionEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_DropConstruct_K2Node_InputActionEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Collective_K2Node_InputAxisEvent_9
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Helicopter_Collective_K2Node_InputAxisEvent_9
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput
{
	float DeltaTimeRatio;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_4
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveElevator_K2Node_InputAxisEvent_4
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcBrakebyYaw
// Size: 0x8D(Inherited: 0x0) 
struct FCalcBrakebyYaw
{
	float CallFunc_SelectFloat_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float CallFunc_BreakVector_X;  // 0x8(0x4)
	float CallFunc_BreakVector_Y;  // 0xC(0x4)
	float CallFunc_BreakVector_Z;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	float CallFunc_BreakVector_X_2;  // 0x18(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x1C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float CallFunc_FInterpTo_ReturnValue;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x38(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x40(0x4)
	float CallFunc_BreakVector_X_3;  // 0x44(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x48(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x4C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x50(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x54(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x58(0x4)
	float CallFunc_Abs_ReturnValue_3;  // 0x5C(0x4)
	float CallFunc_Abs_ReturnValue_4;  // 0x60(0x4)
	float CallFunc_Abs_ReturnValue_5;  // 0x64(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x68(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x6C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x70(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x74(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x8C(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Roll
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput_Roll
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Yaw
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput_Yaw
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Acceleration
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput_Acceleration
{
	float AxisInput;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ROS_UpdateLandingState
// Size: 0x1(Inherited: 0x0) 
struct FROS_UpdateLandingState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsLanded? : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.MC_SetLandingState
// Size: 0x1(Inherited: 0x0) 
struct FMC_SetLandingState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewIsLandedState : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_VehicleToggleCamera_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_VehicleToggleCamera_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupAmmo_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PickupAmmo_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupAmmo_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PickupAmmo_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropConstruct_K2Node_InputActionEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_DropConstruct_K2Node_InputActionEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.UserConstructionScript
// Size: 0x28(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x18(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x24(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetThrustPower
// Size: 0xC(Inherited: 0x0) 
struct FGetThrustPower
{
	float Thrust;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsHealthy_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetPitchNormalized
// Size: 0x24(Inherited: 0x0) 
struct FGetPitchNormalized
{
	float NewParam;  // 0x0(0x4)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x4(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x10(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x14(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRollNormalized
// Size: 0x20(Inherited: 0x0) 
struct FGetRollNormalized
{
	float NewParam;  // 0x0(0x4)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x4(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x10(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x14(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetVelocityLength
// Size: 0x14(Inherited: 0x0) 
struct FGetVelocityLength
{
	float NewParam;  // 0x0(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x4(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcYawResistances
// Size: 0x64(Inherited: 0x0) 
struct FCalcYawResistances
{
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_BreakVector_X;  // 0x4(0x4)
	float CallFunc_BreakVector_Y;  // 0x8(0x4)
	float CallFunc_BreakVector_Z;  // 0xC(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x10(0xC)
	float CallFunc_Abs_ReturnValue;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x20(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x24(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x28(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x30(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x3C(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x40(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x48(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x54(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x58(0x4)
	float CallFunc_Abs_ReturnValue_3;  // 0x5C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x60(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddPitch
// Size: 0x20(Inherited: 0x0) 
struct FAddPitch
{
	float Pitch;  // 0x0(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x4(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x8(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x10(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x14(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetGradualRotationIncrement
// Size: 0x30(Inherited: 0x0) 
struct FGetGradualRotationIncrement
{
	float Roll;  // 0x0(0x4)
	float Pitch;  // 0x4(0x4)
	float CallFunc_GetRollNormalized_NewParam;  // 0x8(0x4)
	float CallFunc_GetPitchNormalized_NewParam;  // 0xC(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_SelectFloat_ReturnValue_2;  // 0x14(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x18(0x4)
	float CallFunc_GetFloatValue_ReturnValue_2;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x2C(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetDistanceFromTheGround
// Size: 0x16C(Inherited: 0x0) 
struct FGetDistanceFromTheGround
{
	float TraceSize;  // 0x0(0x4)
	float distance;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool GotDistance : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x10(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x44(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x50(0x88)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xDA(0x1)
	char pad_219[1];  // 0xDB(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xDC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xFC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x108(0xC)
	char pad_276[4];  // 0x114(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x118(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x120(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x128(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x130(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x138(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x13C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x140(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x150(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x15C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x168(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ResetMovementState
// Size: 0xC(Inherited: 0x0) 
struct FResetMovementState
{
	struct FVector CallFunc_ConsumeMovementInputVector_ReturnValue;  // 0x0(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PolishPitchInput
// Size: 0x48(Inherited: 0x0) 
struct FPolishPitchInput
{
	float Temp_float_Variable;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_GetPitchNormalized_NewParam;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x10(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x18(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x24(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x28(0x4)
	float CallFunc_GetDistanceFromTheGround_Distance;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GetDistanceFromTheGround_GotDistance : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float K2Node_Select_Default;  // 0x40(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x44(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.EnablePhysics
// Size: 0x1C(Inherited: 0x0) 
struct FEnablePhysics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector CallFunc_GetCurrentRotationalVelocity_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_GetCurrentVelocity_ReturnValue;  // 0x10(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetMaxRPM
// Size: 0x4(Inherited: 0x4) 
struct FGetMaxRPM : public FGetMaxRPM
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.SetGroundEffect
// Size: 0x22C(Inherited: 0x0) 
struct FSetGroundEffect
{
	float Height;  // 0x0(0x4)
	float HeightCm;  // 0x4(0x4)
	struct UPhysicalMaterial* PhysMat;  // 0x8(0x8)
	struct FVector Velocity;  // 0x10(0xC)
	float Altitude;  // 0x1C(0x4)
	float Thrust;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct USQPhysicalMaterial* K2Node_DynamicCast_AsSQPhysical_Material;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_GetMainRotorThrust_ReturnValue;  // 0x34(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x40(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x44(0xC)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector CallFunc_GetCurrentVelocity_ReturnValue;  // 0x5C(0xC)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x68(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x78(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x7C(0xC)
	float CallFunc_FClamp_ReturnValue;  // 0x88(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8C(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x98(0x88)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x121(0x1)
	char pad_290_1 : 7;  // 0x122(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x122(0x1)
	char pad_291[1];  // 0x123(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x124(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x128(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x12C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x138(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x150(0xC)
	char pad_348[4];  // 0x15C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x160(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x168(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x170(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x178(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x180(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x184(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x188(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x18C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x198(0xC)
	struct FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult;  // 0x1A4(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DrawDebug
// Size: 0x2D0(Inherited: 0x0) 
struct FDrawDebug
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Draw : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetThrustPower_Thrust;  // 0x4(0x4)
	float CallFunc_GetForwardSpeed_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x10(0x18)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x70(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x80(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x90(0xC)
	float CallFunc_BreakVector_X;  // 0x9C(0x4)
	float CallFunc_BreakVector_Y;  // 0xA0(0x4)
	float CallFunc_BreakVector_Z;  // 0xA4(0x4)
	struct FString CallFunc_Conv_BoolToString_ReturnValue;  // 0xA8(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue_2;  // 0xC0(0x18)
	struct FString CallFunc_Conv_BoolToString_ReturnValue_2;  // 0xD8(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0xE8(0x10)
	struct FRotator CallFunc_GetRotationDiff_NewParam;  // 0xF8(0xC)
	char pad_260[4];  // 0x104(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x108(0x10)
	struct FString CallFunc_Conv_RotatorToString_ReturnValue;  // 0x118(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x128(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_7;  // 0x138(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_8;  // 0x148(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_9;  // 0x158(0x10)
	struct FString CallFunc_Conv_BoolToString_ReturnValue_3;  // 0x168(0x10)
	struct FString CallFunc_Conv_BoolToString_ReturnValue_4;  // 0x178(0x10)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0x188(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_10;  // 0x198(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_11;  // 0x1A8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_12;  // 0x1B8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_13;  // 0x1C8(0x10)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x1D8(0xC)
	char pad_484[4];  // 0x1E4(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_14;  // 0x1E8(0x10)
	struct FString CallFunc_Conv_RotatorToString_ReturnValue_2;  // 0x1F8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_15;  // 0x208(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_16;  // 0x218(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_17;  // 0x228(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_18;  // 0x238(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x248(0xC)
	float CallFunc_BreakVector_X_2;  // 0x254(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x258(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x25C(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x260(0x4)
	struct FVector CallFunc_GetCurrentVelocity_ReturnValue;  // 0x264(0xC)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	struct FString CallFunc_Conv_VectorToString_ReturnValue_2;  // 0x278(0x10)
	int32_t CallFunc_FTrunc_ReturnValue_3;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_19;  // 0x290(0x10)
	struct FIntVector K2Node_MakeStruct_IntVector;  // 0x2A0(0xC)
	char pad_684[4];  // 0x2AC(0x4)
	struct FString CallFunc_Conv_IntVectorToString_ReturnValue;  // 0x2B0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_20;  // 0x2C0(0x10)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRotationDiff
// Size: 0x3C(Inherited: 0x0) 
struct FGetRotationDiff
{
	struct FRotator NewParam;  // 0x0(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x14(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0x18(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x20(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x28(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x2C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x30(0xC)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DebugVariablesMap
// Size: 0xC0(Inherited: 0x0) 
struct FDebugVariablesMap
{
	struct TMap<struct FString, struct FString> Map;  // 0x0(0x50)
	struct FColor Color;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x58(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x68(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x70(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Map_Find_Value;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xA4(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PilotZoom
// Size: 0xC8(Inherited: 0x0) 
struct FPilotZoom
{
	float InputPin;  // 0x0(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x4(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0xC(0x4)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x10(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GetIsUsingFreeLook_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x2C(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x30(0x4)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x34(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x40(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Set UI Enabled
// Size: 0x1(Inherited: 0x0) 
struct FSet UI Enabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enable UI : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoStabilizers
// Size: 0xF0(Inherited: 0x0) 
struct FDoStabilizers
{
	struct FVector VelocityXY;  // 0x0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xC(0xC)
	struct FVector CallFunc_GetCurrentVelocity_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_GetCurrentVelocity_ReturnValue_2;  // 0x48(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x54(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x60(0xC)
	struct FRotator CallFunc_NegateRotator_ReturnValue;  // 0x6C(0xC)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0x78(0xC)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // 0x84(0xC)
	float CallFunc_VSizeXY_ReturnValue;  // 0x90(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x94(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x98(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x9C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0xA8(0x10)
	struct FVector CallFunc_GetVectorValue_ReturnValue;  // 0xB8(0xC)
	char pad_196[4];  // 0xC4(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xC8(0x10)
	float CallFunc_BreakVector_X;  // 0xD8(0x4)
	float CallFunc_BreakVector_Y;  // 0xDC(0x4)
	float CallFunc_BreakVector_Z;  // 0xE0(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0xE4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xE8(0x4)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0xEC(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.IsLanded
// Size: 0x1(Inherited: 0x1) 
struct FIsLanded : public FIsLanded
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CheckPhysics
// Size: 0x8(Inherited: 0x0) 
struct FCheckPhysics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsHealthy_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsHealthy_ReturnValue_2 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsPhysicsEnabled_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x7(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetEngineThrust
// Size: 0x1C(Inherited: 0x0) 
struct FGetEngineThrust
{
	float EngineThrust;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsDestroyed_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetNormalizedHealth_ReturnValue;  // 0xC(0x4)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x10(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DrawDebugLocation
// Size: 0x89(Inherited: 0x0) 
struct FDrawDebugLocation
{
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xC(0xC)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x50(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x5C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x68(0xC)
	char pad_116[4];  // 0x74(0x4)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x88(0x1)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DebugVectorToString
// Size: 0x170(Inherited: 0x0) 
struct FDebugVectorToString
{
	struct FVector Vector;  // 0x0(0xC)
	int32_t digits;  // 0xC(0x4)
	struct FString String;  // 0x10(0x10)
	float CallFunc_BreakVector_X;  // 0x20(0x4)
	float CallFunc_BreakVector_Y;  // 0x24(0x4)
	float CallFunc_BreakVector_Z;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x30(0x18)
	struct FText CallFunc_Conv_FloatToText_ReturnValue_2;  // 0x48(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x60(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA0(0x40)
	struct FText CallFunc_Conv_FloatToText_ReturnValue_3;  // 0xE0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xF8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x138(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x148(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x160(0x10)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRotationFromRoll
// Size: 0x48(Inherited: 0x0) 
struct FDoRotationFromRoll
{
	float CallFunc_GetRollNormalized_NewParam;  // 0x0(0x4)
	struct FVector CallFunc_GetVectorValue_ReturnValue;  // 0x4(0xC)
	float CallFunc_GetForwardSpeed_ReturnValue;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x20(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x30(0xC)
	float CallFunc_BreakVector_X;  // 0x3C(0x4)
	float CallFunc_BreakVector_Y;  // 0x40(0x4)
	float CallFunc_BreakVector_Z;  // 0x44(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRotors
// Size: 0x78(Inherited: 0x0) 
struct FDoRotors
{
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_GetTimeSeconds_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x1C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x24(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x28(0x4)
	float CallFunc_DegreesToRadians_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_IsDestroyed_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FRotator CallFunc_SlerpToUpSideDown_ReturnValue;  // 0x38(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x44(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x48(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x4C(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x54(0x4)
	float CallFunc_SelectFloat_ReturnValue_2;  // 0x58(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x5C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x60(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x64(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x68(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x6C(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x70(0x4)
	float CallFunc_SelectFloat_ReturnValue_3;  // 0x74(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetTailRotorThrust
// Size: 0x14(Inherited: 0x4) 
struct FGetTailRotorThrust : public FGetTailRotorThrust
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_GetEngineThrust_EngineThrust;  // 0x4(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsHealthy_ReturnValue : 1;  // 0x8(0x1)
	float CallFunc_SelectFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetMainRotorThrust
// Size: 0x28(Inherited: 0x4) 
struct FGetMainRotorThrust : public FGetMainRotorThrust
{
	float ReturnValue;  // 0x0(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	float Temp_float_Variable;  // 0x8(0x4)
	float CallFunc_GetRotorEfficiency_Efficiency;  // 0xC(0x4)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsDestroyed_ReturnValue : 1;  // 0x10(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsHealthy_ReturnValue : 1;  // 0x11(0x1)
	char pad_19[1];  // 0x13(0x1)
	float CallFunc_SelectFloat_ReturnValue;  // 0x14(0x4)
	float CallFunc_GetEngineThrust_EngineThrust;  // 0x18(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float K2Node_Select_Default;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetVisualCollective
// Size: 0x4(Inherited: 0x0) 
struct FGetVisualCollective
{
	float Collectives;  // 0x0(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetThrottle
// Size: 0x8(Inherited: 0x4) 
struct FGetThrottle : public FGetThrottle
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_GetEngineThrust_EngineThrust;  // 0x4(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRotorEfficiency
// Size: 0x8C(Inherited: 0x0) 
struct FGetRotorEfficiency
{
	float Efficiency;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x10(0x30)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x40(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x4C(0x4)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue;  // 0x50(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x5C(0x4)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x60(0xC)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x6C(0x4)
	float CallFunc_BreakVector_X;  // 0x70(0x4)
	float CallFunc_BreakVector_Y;  // 0x74(0x4)
	float CallFunc_BreakVector_Z;  // 0x78(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x7C(0x4)
	float CallFunc_GetFloatValue_ReturnValue_2;  // 0x80(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x84(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x88(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HAT Look To
// Size: 0x100(Inherited: 0x0) 
struct FHAT Look To
{
	float CallFunc_BreakVector2D_X;  // 0x0(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_GetIsUsingFreeLook_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector2D CallFunc_GetPitchLimits_ReturnValue;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float CallFunc_BreakVector2D_X_2;  // 0x30(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x34(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x38(0x4)
	struct FVector2D CallFunc_GetYawLimits_ReturnValue;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float CallFunc_BreakVector2D_X_3;  // 0x48(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x4C(0x4)
	float CallFunc_Abs_ReturnValue_3;  // 0x50(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x54(0x8)
	struct FVector2D CallFunc_Multiply_Vector2DVector2D_ReturnValue;  // 0x5C(0x8)
	float CallFunc_BreakVector2D_X_4;  // 0x64(0x4)
	float CallFunc_BreakVector2D_Y_4;  // 0x68(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x6C(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x78(0x88)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetKnots
// Size: 0x18(Inherited: 0x0) 
struct FGetKnots
{
	float Knots;  // 0x0(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x4(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Get UI Tint
// Size: 0x10(Inherited: 0x0) 
struct FGet UI Tint
{
	struct FLinearColor Color;  // 0x0(0x10)

}; 
// Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Is Using Landing Camera
// Size: 0x2(Inherited: 0x0) 
struct FIs Using Landing Camera
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Using Landing Camera : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsActive_ReturnValue : 1;  // 0x1(0x1)

}; 
