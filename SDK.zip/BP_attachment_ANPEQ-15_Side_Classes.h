#pragma once 
#include <BP_attachment_ANPEQ-15_Side_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_ANPEQ-15_Side.BP_attachment_ANPEQ-15_Side_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_ANPEQ-15_Side_C : public UBP_attachment_ANPEQ-15_C
{

}; 



