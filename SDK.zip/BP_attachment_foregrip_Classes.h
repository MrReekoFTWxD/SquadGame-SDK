#pragma once 
#include <BP_attachment_foregrip_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_foregrip.BP_attachment_foregrip_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_foregrip_C : public USQWeaponAttachment
{

}; 



