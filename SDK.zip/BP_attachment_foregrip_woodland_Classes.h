#pragma once 
#include <BP_attachment_foregrip_woodland_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_foregrip_woodland.BP_attachment_foregrip_woodland_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_foregrip_woodland_C : public UBP_attachment_foregrip_C
{

}; 



