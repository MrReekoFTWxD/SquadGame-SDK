#pragma once 
#include "SDK.h" 
 
 
// Function BaseRadialMenu.BaseRadialMenu_C.OnOptionClicked__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnOptionClicked__DelegateSignature
{
	int32_t OptionIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* Context;  // 0x8(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.OnCenterClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCenterClicked__DelegateSignature
{
	struct UBaseRadialMenu_C* Context;  // 0x0(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Centre Hover Changed__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCentre Hover Changed__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Centre Hovered : 1;  // 0x0(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.ExecuteUbergraph_BaseRadialMenu
// Size: 0xE8(Inherited: 0x0) 
struct FExecuteUbergraph_BaseRadialMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4(0x38)
	float K2Node_Event_InDeltaTime;  // 0x3C(0x4)
	int32_t K2Node_CustomEvent_Index_2;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UBP_RadialItemModel_C* K2Node_CustomEvent_Item_2;  // 0x48(0x8)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0x50(0x8)
	struct UBP_RadialMenuModel_C* K2Node_DynamicCast_AsBP_Radial_Menu_Model;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool K2Node_CustomEvent_bCenterMouse : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue_2;  // 0x68(0x8)
	struct UBP_RadialItemModel_C* K2Node_DynamicCast_AsBP_Radial_Item_Model;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UBP_RadialItemModel_C* CallFunc_Array_Get_Item;  // 0x80(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x88(0x8)
	float CallFunc_GetMousePosition_LocationX;  // 0x90(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct USQRadialButton* CallFunc_Array_Get_Item_2;  // 0xA0(0x8)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0xA8(0x8)
	int32_t K2Node_CustomEvent_Index;  // 0xB0(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0xB4(0x8)
	char pad_188[4];  // 0xBC(0x4)
	struct UBP_RadialItemModel_C* CallFunc_Array_Get_Item_3;  // 0xC0(0x8)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0xC8(0x8)
	struct FVector2D CallFunc_Subtract_Vector2DVector2D_ReturnValue;  // 0xD0(0x8)
	struct USQRadialButton* CallFunc_Array_Get_Item_4;  // 0xD8(0x8)
	struct UBP_RadialItemModel_C* K2Node_CustomEvent_Item;  // 0xE0(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.ButtonRelease
// Size: 0x8(Inherited: 0x0) 
struct FButtonRelease
{
	struct UBP_RadialItemModel_C* Item;  // 0x0(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Radial Option Released
// Size: 0x4(Inherited: 0x0) 
struct FRadial Option Released
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonDoubleClick
// Size: 0x2E1(Inherited: 0x160) 
struct FOnMouseButtonDoubleClick : public FOnMouseButtonDoubleClick
{
	struct FGeometry InMyGeometry;  // 0x0(0x38)
	struct FPointerEvent InMouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0x160(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x164(0x4)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x168(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x170(0xB8)
	struct FEventReply CallFunc_SetUserFocus_ReturnValue;  // 0x228(0xB8)
	char pad_1081_1 : 7;  // 0x439(0x1)
	bool CallFunc_IsMouseInCenterHitbox_CenterHitbox : 1;  // 0x2E0(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonDown
// Size: 0x5F0(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	int32_t SelectionCounter;  // 0x160(0x4)
	int32_t SelectionIndex;  // 0x164(0x4)
	struct FEventReply Ret;  // 0x168(0xB8)
	struct FKey CallFunc_PointerEvent_GetEffectingButton_ReturnValue;  // 0x220(0x18)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x238(0xB8)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x2F0(0x1)
	struct FEventReply CallFunc_SetUserFocus_ReturnValue;  // 0x2F8(0xB8)
	char pad_1289_1 : 7;  // 0x509(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_2 : 1;  // 0x3B0(0x1)
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0x3B4(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x3B8(0x4)
	char pad_1298_1 : 7;  // 0x512(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3BC(0x1)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x3C0(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue_2;  // 0x478(0xB8)
	char pad_1667_1 : 7;  // 0x683(0x1)
	bool CallFunc_IsMouseInCenterHitbox_CenterHitbox : 1;  // 0x530(0x1)
	struct FEventReply CallFunc_SetUserFocus_ReturnValue_2;  // 0x538(0xB8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.ButtonPress
// Size: 0x8(Inherited: 0x0) 
struct FButtonPress
{
	struct UBP_RadialItemModel_C* Item;  // 0x0(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Reset
// Size: 0x1(Inherited: 0x0) 
struct FReset
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCenterMouse : 1;  // 0x0(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Radial Option Clicked
// Size: 0x4(Inherited: 0x0) 
struct FRadial Option Clicked
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.OnKeyUp
// Size: 0x379(Inherited: 0x128) 
struct FOnKeyUp : public FOnKeyUp
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FKeyEvent InKeyEvent;  // 0x38(0x38)
	struct FEventReply ReturnValue;  // 0x70(0xB8)
	struct FEventReply Ret;  // 0x128(0xB8)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x1E0(0x18)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x1F8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x2B0(0xB8)
	struct TArray<struct FKey> CallFunc_GetKeysMappedToAction_Keys;  // 0x368(0x10)
	char pad_1184_1 : 7;  // 0x4A0(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x378(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonUp
// Size: 0x2F9(Inherited: 0x160) 
struct FOnMouseButtonUp : public FOnMouseButtonUp
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FKey CallFunc_PointerEvent_GetEffectingButton_ReturnValue;  // 0x160(0x18)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x178(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x180(0xB8)
	struct FEventReply CallFunc_SetUserFocus_ReturnValue;  // 0x238(0xB8)
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0x2F0(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x2F4(0x4)
	char pad_1105_1 : 7;  // 0x451(0x1)
	bool CallFunc_IsMouseInCenterHitbox_CenterHitbox : 1;  // 0x2F8(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.CreateToolTip
// Size: 0x20(Inherited: 0x0) 
struct FCreateToolTip
{
	struct UBP_RadialItemModel_C* InOuterItemModel;  // 0x0(0x8)
	struct UUserWidget* OutToolTip;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct URadialEntry_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.IsMouseInCenterHitbox
// Size: 0xE0(Inherited: 0x0) 
struct FIsMouseInCenterHitbox
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CenterHitbox : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool L Is Hovering Center : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetMousePosition_LocationX;  // 0x18(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x30(0x8)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x38(0x8)
	struct FVector2D CallFunc_Subtract_Vector2DVector2D_ReturnValue;  // 0x40(0x8)
	float CallFunc_VSize2D_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x50(0x10)
	struct FGeometry CallFunc_GetCachedGeometry_ReturnValue;  // 0x60(0x38)
	struct FVector2D CallFunc_GetAbsoluteSize_ReturnValue;  // 0x98(0x8)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue;  // 0xA0(0x8)
	float CallFunc_VSize2D_ReturnValue_2;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_2;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xD0(0x10)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.GetOuterWidgetIndex
// Size: 0x6C(Inherited: 0x0) 
struct FGetOuterWidgetIndex
{
	int32_t WidgetIndex;  // 0x0(0x4)
	float TempIndexCounter;  // 0x4(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x8(0x8)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x20(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x28(0x4)
	float CallFunc_GetMousePosition_LocationX;  // 0x2C(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x38(0x8)
	struct FVector2D CallFunc_Subtract_Vector2DVector2D_ReturnValue;  // 0x40(0x8)
	float CallFunc_BreakVector2D_X;  // 0x48(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x4C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x50(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x54(0x4)
	float CallFunc_DegAtan2_ReturnValue;  // 0x58(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x5C(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x60(0x4)
	int32_t CallFunc_FFloor_ReturnValue;  // 0x64(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x68(0x4)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Add Center Widget
// Size: 0x1B(Inherited: 0x0) 
struct FAdd Center Widget
{
	struct USQRadialButton* Entry;  // 0x0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x8(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1A(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Clear Menu
// Size: 0x19(Inherited: 0x0) 
struct FClear Menu
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x8(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.AddChild
// Size: 0x54(Inherited: 0x0) 
struct FAddChild
{
	struct USQRadialButton* Entry;  // 0x0(0x8)
	struct UBP_RadialItemModel_C* Model;  // 0x8(0x8)
	float Temp_float_Variable;  // 0x10(0x4)
	float Temp_float_Variable_2;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	float Temp_float_Variable_3;  // 0x24(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x28(0x4)
	float Temp_float_Variable_4;  // 0x2C(0x4)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	uint8_t  Temp_byte_Variable;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62[2];  // 0x3E(0x2)
	float K2Node_Select_Default;  // 0x40(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x44(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x48(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x50(0x4)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.LayoutOuterRing
// Size: 0x128(Inherited: 0x0) 
struct FLayoutOuterRing
{
	uint8_t  LastPlaceWidgetSize;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float TempCurrentRadialOffset;  // 0x4(0x4)
	float Temp_float_Variable;  // 0x8(0x4)
	uint8_t  Temp_byte_Variable;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float Temp_float_Variable_2;  // 0x10(0x4)
	float Temp_float_Variable_3;  // 0x14(0x4)
	float Temp_float_Variable_4;  // 0x18(0x4)
	float Temp_float_Variable_5;  // 0x1C(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x20(0x8)
	float Temp_float_Variable_6;  // 0x28(0x4)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x2C(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	float Temp_float_Variable_7;  // 0x44(0x4)
	float CallFunc_GetViewportScale_ReturnValue;  // 0x48(0x4)
	float Temp_float_Variable_8;  // 0x4C(0x4)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue_2;  // 0x50(0x8)
	float Temp_float_Variable_9;  // 0x58(0x4)
	uint8_t  Temp_byte_Variable_2;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	float Temp_float_Variable_10;  // 0x60(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x64(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x68(0x4)
	uint8_t  Temp_byte_Variable_3;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	float Temp_float_Variable_11;  // 0x70(0x4)
	float Temp_float_Variable_12;  // 0x74(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x78(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x7C(0x4)
	float K2Node_Select_Default;  // 0x80(0x4)
	float CallFunc_DegCos_ReturnValue;  // 0x84(0x4)
	float CallFunc_DegSin_ReturnValue;  // 0x88(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x8C(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x94(0x4)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0xA8(0x8)
	float K2Node_Select_Default_2;  // 0xB0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xB4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0xC0(0x8)
	struct FVector2D CallFunc_GetSize_ReturnValue;  // 0xC8(0x8)
	float CallFunc_BreakVector2D_X;  // 0xD0(0x4)
	float CallFunc_BreakVector2D_Y;  // 0xD4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xD8(0x4)
	float K2Node_Select_Default_3;  // 0xDC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0xE0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0xE4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0xE8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0xEC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0xF0(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xF4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0xF8(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0xFC(0x8)
	struct FVector2D CallFunc_Add_Vector2DVector2D_ReturnValue;  // 0x104(0x8)
	struct FWidgetTransform K2Node_MakeStruct_WidgetTransform;  // 0x10C(0x1C)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Notify HoverOver
// Size: 0x30(Inherited: 0x0) 
struct FNotify HoverOver
{
	struct USQRadialButton* NewHover;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsMouseInCenterHitbox_CenterHitbox : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0xC(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct USQRadialButton* CallFunc_GetHoverWidget_HoverWidget;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x28(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.GetHoverWidget
// Size: 0x32(Inherited: 0x0) 
struct FGetHoverWidget
{
	struct USQRadialButton* HoverWidget;  // 0x0(0x8)
	struct USQRadialButton* Return;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x31(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.SetHoveringWidget
// Size: 0x21(Inherited: 0x0) 
struct FSetHoveringWidget
{
	struct USQRadialButton* NewHover;  // 0x0(0x8)
	struct USQRadialButton* OldHover;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct URadialCenter_Deployable_C* K2Node_DynamicCast_AsRadial_Center_Deployable;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.FadeAnimation
// Size: 0x1E(Inherited: 0x0) 
struct FFadeAnimation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Reverse : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char EUMGSequencePlayMode Temp_byte_Variable;  // 0x2(0x1)
	char EUMGSequencePlayMode Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_GetAnimationCurrentTime_ReturnValue;  // 0x8(0x4)
	char EUMGSequencePlayMode K2Node_Select_Default;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsAnimationPlaying_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsAnimationPlayingForward_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1D(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.CreateMenuFromModel
// Size: 0x19(Inherited: 0x0) 
struct FCreateMenuFromModel
{
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0x0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UBP_RadialMenuModel_C* K2Node_DynamicCast_AsBP_Radial_Menu_Model;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.CloseSelf
// Size: 0x9(Inherited: 0x0) 
struct FCloseSelf
{
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0x0(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsMouseInCenterHitbox_CenterHitbox : 1;  // 0x8(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.GetSelectedOuterWidget
// Size: 0xAD(Inherited: 0x0) 
struct FGetSelectedOuterWidget
{
	int32_t Output_Get;  // 0x0(0x4)
	float Actual Angle;  // 0x4(0x4)
	float LocationAngle;  // 0x8(0x4)
	float Temp_float_Variable;  // 0xC(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetMousePosition_LocationX;  // 0x18(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float Temp_float_Variable_2;  // 0x24(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x28(0x8)
	float Temp_float_Variable_3;  // 0x30(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x3C(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x40(0x8)
	uint8_t  Temp_byte_Variable;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x4C(0x8)
	float Temp_float_Variable_4;  // 0x54(0x4)
	struct FVector2D CallFunc_Subtract_Vector2DVector2D_ReturnValue;  // 0x58(0x8)
	float CallFunc_BreakVector2D_X;  // 0x60(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x64(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x68(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x6C(0x4)
	float CallFunc_DegAtan2_ReturnValue;  // 0x70(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x74(0x4)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x78(0x8)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x80(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x84(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x88(0x4)
	float K2Node_Select_Default;  // 0x8C(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue_2;  // 0x90(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x9A(0x1)
	char pad_155_1 : 7;  // 0x9B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9B(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0xA4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xAC(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Sort Radial Z Order
// Size: 0x41(Inherited: 0x0) 
struct FSort Radial Z Order
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t Temp_int_Variable_2;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_GetSelectedOuterWidget_Output_Get;  // 0x18(0x4)
	float CallFunc_GetSelectedOuterWidget_Actual_Angle;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct USQRadialButton* CallFunc_Array_Get_Item;  // 0x28(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x30(0x8)
	int32_t K2Node_Select_Default;  // 0x38(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.CreateRadialWidget
// Size: 0x20(Inherited: 0x0) 
struct FCreateRadialWidget
{
	USQUserWidget* WidgetClass;  // 0x0(0x8)
	struct USQUserWidget* CreatedWidget;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct USQUserWidget* CallFunc_Create_ReturnValue;  // 0x18(0x8)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Return to Previous Menu
// Size: 0x19(Inherited: 0x0) 
struct FReturn to Previous Menu
{
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue_2;  // 0x4(0x4)
	UBP_RadialMenuModel_C* CallFunc_Array_Get_Item;  // 0x8(0x8)
	int32_t CallFunc_Array_LastIndex_ReturnValue_3;  // 0x10(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.Finished Closed Animation
// Size: 0x2(Inherited: 0x0) 
struct FFinished Closed Animation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsAnimationPlayingForward_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BaseRadialMenu.BaseRadialMenu_C.GetWidgetCenter
// Size: 0x1C(Inherited: 0x0) 
struct FGetWidgetCenter
{
	struct FVector2D WidgetCenter;  // 0x0(0x8)
	struct UCanvasPanelSlot* K2Node_DynamicCast_AsCanvas_Panel_Slot;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector2D CallFunc_GetPosition_ReturnValue;  // 0x14(0x8)

}; 
